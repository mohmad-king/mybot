const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const aiDB = new Database("Json-db/Bots/aiDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('set-apikey')
        .setDescription('تحديد api key gemini الذكاء الصناعي')
        .addStringOption(Option =>
            Option
                .setName('key')
                .setDescription('اكتب الايبي هنا')
                .setRequired(true)), // or false
    async execute(interaction) {
        try {
            const apikey = interaction.options.getString('key');
            await aiDB.set(`ai_key_${interaction.guild.id}`, apikey);
            return interaction.reply({ content: '**تم تحديد apiKey بنجاح**' });
        } catch {
            return;
        }
    }
};
