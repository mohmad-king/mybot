const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const aiDB = new Database("Json-db/Bots/aiDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const aiList = tokens.get("ai");
if (!aiList || aiList.length === 0) return;

aiList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client29 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client29.commands = new Collection();
  client29.events = new Collection();
  client29.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client29);

  require("../../events/requireBots/ai-commands")(client29);

  // ── تحميل الأوامر ──
  const aiSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand29");
  client29.aiSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          aiSlashCommands.push(command.data.toJSON());
          client29.aiSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[ai] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client29.once("ready", async () => {
    console.log(`[ai] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client29.user.id), { body: aiSlashCommands });
    } catch (err) {
      console.error(`[ai] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client29.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client29.aiSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client29);
    } catch (err) {
      console.error(`[ai] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client29.login(token)
    .then(() => liveBots.set(token, client29))
    .catch(async () => {
      const list = tokens.get("ai") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("ai", filtered);
      console.log(`[ai] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
