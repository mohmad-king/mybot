const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const auctionDB = new Database("Json-db/Bots/auctionDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const auctionList = tokens.get("auction");
if (!auctionList || auctionList.length === 0) return;

auctionList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client30 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client30.commands = new Collection();
  client30.events = new Collection();
  client30.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client30);

  require("../../events/requireBots/auction-commands")(client30);

  // ── تحميل الأوامر ──
  const auctionSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand30");
  client30.auctionSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          auctionSlashCommands.push(command.data.toJSON());
          client30.auctionSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[auction] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client30.once("ready", async () => {
    console.log(`[auction] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client30.user.id), { body: auctionSlashCommands });
    } catch (err) {
      console.error(`[auction] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client30.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client30.auctionSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client30);
    } catch (err) {
      console.error(`[auction] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client30.login(token)
    .then(() => liveBots.set(token, client30))
    .catch(async () => {
      const list = tokens.get("auction") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("auction", filtered);
      console.log(`[auction] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
