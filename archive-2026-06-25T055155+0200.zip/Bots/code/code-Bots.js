const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const codeDB = new Database("Json-db/Bots/codeDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const codeList = tokens.get("code");
if (!codeList || codeList.length === 0) return;

codeList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client99 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client99.commands = new Collection();
  client99.events = new Collection();
  client99.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client99);

  require("../../events/requireBots/code-commands")(client99);

  // ── تحميل الأوامر ──
  const codeSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand99");
  client99.codeSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          codeSlashCommands.push(command.data.toJSON());
          client99.codeSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[code] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client99.once("ready", async () => {
    console.log(`[code] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client99.user.id), { body: codeSlashCommands });
    } catch (err) {
      console.error(`[code] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client99.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client99.codeSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client99);
    } catch (err) {
      console.error(`[code] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client99.login(token)
    .then(() => liveBots.set(token, client99))
    .catch(async () => {
      const list = tokens.get("code") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("code", filtered);
      console.log(`[code] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
