const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require("discord.js");
const { Database } = require('st.db');
const ticketDB = new Database("Json-db/Bots/ticketDB")
module.exports = {
     //ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('setup-ticket')
        .setDescription('Setup the ticket system')
        .addStringOption(option =>
            option.setName('ticket_name')
                .setDescription('Specify the ticket name')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message_content')
                .setDescription('Specify the message content')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('button_name')
                .setDescription('Specify the button name')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('button_color')
                .setDescription('Specify the button color')
                .setRequired(true)
                .addChoices(
                    { name: 'Primary', value: 'Primary' },
                    { name: 'Secondary', value: 'Secondary' },
                    { name: 'Success', value: 'Success' },
                    { name: 'Danger', value: 'Danger' }))
        .addRoleOption(option =>
            option.setName('support_role')
                .setDescription('Specify the support role')
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('category')
                .setDescription('Specify the category')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('internal_ticket')
                .setDescription('Specify if the ticket is internal (yes/no)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('ticket_image')
                .setDescription('Specify the ticket image')
                .setRequired(false)),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: 'You do not have the necessary permissions to use this command.', ephemeral: true });
        }

        const name = interaction.options.getString('ticket_name');
        let description = interaction.options.getString('message_content');
        const color = interaction.options.getString('ticket_color');
        const buttonName = interaction.options.getString('button_name');
        const support = interaction.options.getRole('support_role');
        const category = interaction.options.getChannel('category');
        const image = interaction.options.getString('ticket_image');
        let internal = interaction.options.getString('internal_ticket');
        const colorButton = interaction.options.getString('button_color');
        
        description = description.replace(/\\n/g, '\n');
        internal = internal.replace(/\\n/g, '\n');
        
        const embed = new EmbedBuilder()
            //.setColor('Random') 
            .setThumbnail(interaction.guild.iconURL())
            .setTitle(name)
            .setDescription(description)
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        if (image) {
            embed.setImage(image);
        }

        const button = new ButtonBuilder()
            .setCustomId('ticket')
            .setLabel(buttonName)
            .setStyle(ButtonStyle[colorButton]);

        const row = new ActionRowBuilder().addComponents(button);

        interaction.channel.send({ embeds: [embed], components: [row] }).then(async (msg) => {
            await ticketDB.set(`Ticket_${interaction.channel.id}_${msg.id}`, { Support: support.id, category: category.id, internal: internal });
        });

        interaction.reply({ content: 'Ticket setup successfully.', ephemeral: true });
},
};
