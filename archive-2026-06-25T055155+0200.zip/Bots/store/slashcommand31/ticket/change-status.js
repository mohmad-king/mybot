const { Client, Collection, PermissionsBitField, SlashCommandBuilder, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, MessageAttachment, ButtonStyle, Message } = require("discord.js");
const { Database } = require("st.db");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('change-status')
        .setDescription('Change the bot\'s status')
        .addStringOption(option =>
            option.setName('activity')
                .setDescription('The new activity message')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('type')
                .setDescription('The type of activity')
                .setRequired(true)
                .addChoices(
                    { name: 'Playing', value: 'PLAYING' },
                    { name: 'Streaming', value: 'STREAMING' },
                    { name: 'Listening', value: 'LISTENING' },
                    { name: 'Watching', value: 'WATCHING' },
                    { name: 'Competing', value: 'COMPETING' }
                ))
        .addStringOption(option =>
            option.setName('presence')
                .setDescription('The presence status')
                .setRequired(true)
                .addChoices(
                    { name: 'Online', value: 'online' },
                    { name: 'Do Not Disturb', value: 'dnd' },
                    { name: 'Idle', value: 'idle' },
                    { name: 'Invisible', value: 'invisible' }
                )),
    async execute(interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });
            const activityMessage = interaction.options.getString('activity');
            const activityType = interaction.options.getString('type');
            const presenceStatus = interaction.options.getString('presence');

            await interaction.client.user.setPresence({
                activities: [{ name: activityMessage, type: activityType }],
                status: presenceStatus
            });

            await interaction.editReply('The bot\'s status will be updated within seconds. Status changed successfully!'); // Edit the reply to indicate success
        } catch (error) {
            console.error('An error occurred while changing the status:', error);

            await interaction.editReply('An error occurred while changing the status. Please try again.'); // Edit the reply to indicate error
        }
    }
};