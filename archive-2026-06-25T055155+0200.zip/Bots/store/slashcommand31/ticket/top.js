const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { Database } = require("st.db");
let ticketDB = new Database("Json-db/Bots/ticketDB");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('top')
        .setDescription('Displays the top users with the highest points in the server.'),
    async execute(interaction) {
        const serverId = interaction.guild.id;
        const allKeys = ticketDB.all(); // Get all stored keys
        const serverPoints = allKeys.filter(entry => entry.key.startsWith(`Points_`) && entry.key.includes(`_${serverId}`));

        const sortedPoints = serverPoints
            .map(entry => ({
                userId: entry.key.split('_')[1], 
                points: entry.value
            }))
            .sort((a, b) => b.points - a.points)
            .slice(0, 10); // Top 10 users

        if (sortedPoints.length === 0) {
            return interaction.reply({ content: 'No points data found in this server.', ephemeral: true });
        }

        const leaderboard = sortedPoints.map((entry, index) => {
            const user = interaction.guild.members.cache.get(entry.userId)?.user || { username: 'Unknown User', id: entry.userId };
            return `**${index + 1}.** ${user.username} - **${entry.points} points**`;
        }).join('\n');

        const embed = new EmbedBuilder()
            .setTitle('🏆 Server Leaderboard')
            .setColor(0xFFD700)
            .setDescription(leaderboard)
            .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },
};