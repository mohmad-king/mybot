const { Client, Collection, PermissionsBitField, SlashCommandBuilder, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, MessageAttachment, ButtonStyle, Message } = require("discord.js");
const { Database } = require("st.db");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('change-avatar')
        .setDescription('Change the bot\'s avatar')
        .addStringOption(option =>
            option.setName('avatar_url')
                .setDescription('The URL of the new avatar')
                .setRequired(true)),
    async execute(interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });
            const avatarURL = interaction.options.getString('avatar_url');
            await interaction.client.user.setAvatar(avatarURL);

            await interaction.editReply('Avatar changed successfully!'); // Edit the reply to indicate success
        } catch (error) {
            console.error('An error occurred while changing the avatar:', error);

            await interaction.editReply('An error occurred while changing the avatar. Please try again.'); // Edit the reply to indicate error
        }
    }
};