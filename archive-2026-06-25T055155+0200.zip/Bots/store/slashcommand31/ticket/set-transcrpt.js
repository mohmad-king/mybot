const { SlashCommandBuilder } = require('discord.js');
const { Database } = require('st.db');
let ticketDB = new Database("Json-db/Bots/ticketDB");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('set-transcripts')
        .setDescription('Set the log channel for ticket transcripts')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Select the channel to save ticket logs')
                .setRequired(true)
                .addChannelTypes(0) // Only text channels
        ),
    async execute(interaction) {
        const logChannel = interaction.options.getChannel('channel');
        if (!logChannel || logChannel.type !== 0) { // Check if the channel is a text channel
            return interaction.reply({ content: 'Please select a valid text channel!', ephemeral: true });
        }

        // Set the log channel in the database
        ticketDB.set(`LogsRoom_${interaction.guild.id}`, logChannel.id);

        return interaction.reply({ content: `Ticket logs will now be saved in ${logChannel}`, ephemeral: true });
    },
};
