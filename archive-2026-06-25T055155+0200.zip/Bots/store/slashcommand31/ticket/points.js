const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { Database } = require("st.db");
let ticketDB = new Database("Json-db/Bots/ticketDB");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('points')
        .setDescription('Check your points or another user\'s points.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to check points for.')
                .setRequired(false)),
    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const serverId = interaction.guild.id;
        const points = ticketDB.get(`Points_${targetUser.id}_${serverId}`) || 0;

        const embed = new EmbedBuilder()
            .setTitle('User Points')
            .setColor(0x00FF00)
            .setDescription(`Points for ${targetUser.username}: **${points}**`)
            .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};