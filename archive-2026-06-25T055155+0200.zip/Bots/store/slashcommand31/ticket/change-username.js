const { Client, Collection, PermissionsBitField, SlashCommandBuilder, GatewayIntentBits, Partials, EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder, ButtonBuilder, MessageAttachment, ButtonStyle, Message } = require("discord.js");
const { Database } = require("st.db");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('change-username')
        .setDescription('Change the bot\'s username')
        .addStringOption(option =>
            option.setName('username')
                .setDescription('The new username')
                .setRequired(true)),
    async execute(interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });
            const newUsername = interaction.options.getString('username');
            await interaction.client.user.setUsername(newUsername);

            await interaction.editReply('Username changed successfully!'); // Short success message
        } catch (error) {
            console.error('An error occurred while changing the username:', error);

            await interaction.editReply('An error occurred. Please try again.'); // Short error message
        }
    }
};