const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require("discord.js");
const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('come')
        .setDescription('Call someone')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select a member')
                .setRequired(true)),

    async execute(Interaction) {
        const user = Interaction.options.getMember('user');
        
        if (user.id === Interaction.user.id) {
            return Interaction.reply({ content: "You cannot call yourself!", ephemeral: true });
        }

        if (!Interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return Interaction.reply({ content: "You do not have permission to use this command.", ephemeral: true });
        }

        const Embed = new EmbedBuilder()
            .setAuthor({ name: `Call from ${Interaction.guild.name}`, iconURL: Interaction.guild.iconURL() })
            .setFooter({ text: Interaction.guild.name, iconURL: Interaction.guild.iconURL() })
            .setThumbnail(Interaction.guild.iconURL())
            .setColor('Green')
            .setTitle('Please Come')
            .setDescription(`**You have been called, ${user.displayName}, in the server ${Interaction.guild.name} 💎**`);

        const Row = new ActionRowBuilder()
            .addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${Interaction.guild.id}/${Interaction.channel.id}`).setLabel('Click to join'));

        user.send({ embeds: [Embed], components: [Row] });
        Interaction.reply({ content: `**🟢 ${user} has been successfully summoned.**` });
    }
};