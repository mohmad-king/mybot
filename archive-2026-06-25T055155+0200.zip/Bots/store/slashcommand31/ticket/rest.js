const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Database } = require("st.db");
let ticketDB = new Database("Json-db/Bots/ticketDB");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reset')
        .setDescription('Reset points for a specific user, all users, or based on criteria.')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('Reset points for a specific user.')
                .addUserOption(option =>
                    option.setName('target')
                        .setDescription('The user to reset points for.')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('all')
                .setDescription('Reset points for all users in this server.'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('below')
                .setDescription('Reset points for all users with points below a certain value.')
                .addIntegerOption(option =>
                    option.setName('value')
                        .setDescription('The maximum point value to reset.')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator), // Restrict command to admins
    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const serverId = interaction.guild.id;

        if (subcommand === 'user') {
            const targetUser = interaction.options.getUser('target');
            const userKey = `Points_${targetUser.id}_${serverId}`;
            
            if (!ticketDB.has(userKey)) {
                return interaction.reply({ content: `This user has no points to reset.`, ephemeral: true });
            }

            ticketDB.delete(userKey);
            return interaction.reply({ content: `Points for ${targetUser.username} have been reset successfully.` });

        } else if (subcommand === 'all') {
            const allKeys = ticketDB.all();
            const serverKeys = allKeys.filter(entry => entry.key.startsWith(`Points_`) && entry.key.endsWith(`_${serverId}`));

            serverKeys.forEach(entry => ticketDB.delete(entry.key));

            return interaction.reply({ content: `All points in this server have been reset successfully.` });

        } else if (subcommand === 'below') {
            const value = interaction.options.getInteger('value');
            const allKeys = ticketDB.all();
            const serverKeys = allKeys.filter(entry => entry.key.startsWith(`Points_`) && entry.key.endsWith(`_${serverId}`));
            const resetUsers = serverKeys.filter(entry => entry.value < value);

            if (resetUsers.length === 0) {
                return interaction.reply({ content: `No users found with points below ${value}.`, ephemeral: true });
            }

            resetUsers.forEach(entry => ticketDB.delete(entry.key));

            return interaction.reply({ content: `Reset points for ${resetUsers.length} users with points below ${value}.` });
        }
    },
};