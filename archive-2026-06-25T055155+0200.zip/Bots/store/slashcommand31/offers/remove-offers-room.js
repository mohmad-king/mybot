const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const offersDB = new Database("Json-db/Bots/offersDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('remove-offers-room')
        .setDescription('إزالة روم من قائمة العروض')
        .addChannelOption(option => 
            option
                .setName('room')
                .setDescription('الروم')
                .setRequired(true)),
    async execute(interaction) {
        try {
            const room = interaction.options.getChannel('room');
            const guildId = interaction.guild.id;

            // Get the current list of offer rooms or initialize as empty array
            let offerRooms = await offersDB.get(`offers_room_${guildId}`);
            if (!Array.isArray(offerRooms)) {
                offerRooms = [];
            }


            if (offerRooms.includes(room.id)) {
                offerRooms = offerRooms.filter(id => id !== room.id);
                await offersDB.set(`offers_room_${guildId}`, offerRooms);
                return interaction.reply({ content: `**تم إزالة الروم بنجاح**` });
            } else {
                return interaction.reply({ content: `**هذا الروم غير موجود في القائمة**` });
            }
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: `**حدث خطأ ما. حاول مرة أخرى لاحقًا**` });
        }
    }
};
