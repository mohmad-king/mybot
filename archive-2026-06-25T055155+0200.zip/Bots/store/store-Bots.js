const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const storeDB = new Database("Json-db/Bots/storeDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const storeList = tokens.get("store");
if (!storeList || storeList.length === 0) return;

storeList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client31 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client31.commands = new Collection();
  client31.events = new Collection();
  client31.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client31);

  require("../../events/requireBots/store-commands")(client31);

  // ── تحميل الأوامر ──
  const storeSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand31");
  client31.storeSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          storeSlashCommands.push(command.data.toJSON());
          client31.storeSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[store] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client31.once("ready", async () => {
    console.log(`[store] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client31.user.id), { body: storeSlashCommands });
    } catch (err) {
      console.error(`[store] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client31.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client31.storeSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client31);
    } catch (err) {
      console.error(`[store] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client31.login(token)
    .then(() => liveBots.set(token, client31))
    .catch(async () => {
      const list = tokens.get("store") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("store", filtered);
      console.log(`[store] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
