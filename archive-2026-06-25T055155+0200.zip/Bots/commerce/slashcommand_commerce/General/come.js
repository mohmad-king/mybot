const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('come')
        .setDescription('استدعاء شخص')
        .addUserOption(Option => Option
            .setName(`user`)
            .setDescription(`الشخص المراد استدعائه`)
            .setRequired(true)),
    async execute(interaction) {
        try {
            await interaction.deferReply({ fetchReply: true, ephemeral: false });
            const user = interaction.options.getUser(`user`);
            user.send({ content: `**تم استدعائك بواسطة : ${interaction.user}\nفي : ${interaction.channel} يرجا قدوم في اسرع وقت**` })
                .then(() => interaction.editReply({ content: `**تم الارسال للشخص بنجاح**` }))
                .catch(() => interaction.editReply({ content: `**لم استطع الارسال للشخص**` }));
        } catch {
            return interaction.editReply({ content: `**لم استطع الارسال للشخص**` });
        }
    }
}
