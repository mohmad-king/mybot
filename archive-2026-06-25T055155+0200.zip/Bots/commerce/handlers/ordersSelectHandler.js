/**
 * ==========================================
 * Orders / Offer Select Menu + Modal Handler
 * يتعامل مع القائمة المنسدلة (select_bot) التي
 * تُنشر بواسطة setup-orders و setup-offer
 * ==========================================
 */
const {
  Events,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
} = require("discord.js");
const { Database } = require("st.db");

const ordersDB = new Database("Json-db/Bots/ordersDB.json");
const offerDB = new Database("Json-db/Bots/offerDB.json");

// تعريف كل نوع طلب: العنوان، الإيموجي، ومفاتيح الداتابيس الخاصة بالروم والرول
const ORDER_TYPES = {
  orderProduct: { label: "منتج", emoji: "🛍️", roomKey: "products_room", roleKey: "products_role" },
  orderCurrency: { label: "عملة", emoji: "💵", roomKey: "currency_room", roleKey: "currency_role" },
  orderServices: { label: "خدمة", emoji: "🛎️", roomKey: "services_room", roleKey: "services_role" },
  orderDesigns: { label: "تصميم", emoji: "🖼️", roomKey: "designs_room", roleKey: "designs_role" },
};

function getDB(interaction, type) {
  // نفس select_bot يُستخدم في setup-orders و setup-offer
  // نتحقق من أي داتابيس فيها روم محفوظ فعليًا لهذا النوع تحديدًا في هذا السيرفر
  const ordersRoom = ordersDB.get(`${type.roomKey}_${interaction.guild.id}`);
  if (ordersRoom) return ordersDB;

  const offerRoom = offerDB.get(`${type.roomKey}_${interaction.guild.id}`);
  if (offerRoom) return offerDB;

  // لو مفيش روم محفوظ في الاتنين، نرجع ordersDB كافتراضي (سيتم رفض الطلب بسبب عدم وجود روم)
  return ordersDB;
}

module.exports = (clientCommerce) => {
  clientCommerce.on(Events.InteractionCreate, async (interaction) => {
    try {
      // ===== 1) التعامل مع القائمة المنسدلة select_bot =====
      if (interaction.isStringSelectMenu() && interaction.customId === "select_bot") {
        const selected = interaction.values[0];

        if (selected === "Reset_Selected_order") {
          return interaction.reply({
            content: "**تم إعادة التعيين، اختر نوع طلبك من جديد.**",
            ephemeral: true,
          });
        }

        const type = ORDER_TYPES[selected];
        if (!type) return;

        const modal = new ModalBuilder()
          .setCustomId(`order_modal_${selected}`)
          .setTitle(`طلب ${type.label}`);

        const detailsInput = new TextInputBuilder()
          .setCustomId("order_details")
          .setLabel(`اكتب تفاصيل ${type.label} المطلوب`)
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder("مثال: اسم المنتج، الكمية، طريقة الدفع المفضلة...")
          .setRequired(true)
          .setMaxLength(1000);

        const noteInput = new TextInputBuilder()
          .setCustomId("order_note")
          .setLabel("ملاحظات إضافية (اختياري)")
          .setStyle(TextInputStyle.Short)
          .setRequired(false)
          .setMaxLength(200);

        modal.addComponents(
          new ActionRowBuilder().addComponents(detailsInput),
          new ActionRowBuilder().addComponents(noteInput)
        );

        return interaction.showModal(modal);
      }

      // ===== 2) التعامل مع إرسال المودال =====
      if (interaction.isModalSubmit() && interaction.customId.startsWith("order_modal_")) {
        const selected = interaction.customId.replace("order_modal_", "");
        const type = ORDER_TYPES[selected];
        if (!type) return;

        await interaction.deferReply({ ephemeral: true });

        const db = getDB(interaction, type);
        const roomId = db.get(`${type.roomKey}_${interaction.guild.id}`);
        const roleId = db.get(`${type.roleKey}_${interaction.guild.id}`);

        if (!roomId) {
          return interaction.editReply({
            content: "**⛔ لم يتم تحديد روم استقبال هذا النوع من الطلبات بعد، يرجى إبلاغ الإدارة.**",
          });
        }

        const targetRoom = await interaction.guild.channels.fetch(roomId).catch(() => null);
        if (!targetRoom) {
          return interaction.editReply({
            content: "**⛔ روم استقبال الطلبات غير موجود حاليًا، يرجى إبلاغ الإدارة.**",
          });
        }

        const details = interaction.fields.getTextInputValue("order_details");
        const note = interaction.fields.getTextInputValue("order_note") || "لا يوجد";

        const embed = new EmbedBuilder()
          .setColor("#00b894")
          .setAuthor({
            name: interaction.user.tag,
            iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
          })
          .setTitle(`${type.emoji} طلب ${type.label} جديد`)
          .addFields(
            { name: "العميل", value: `${interaction.user}`, inline: true },
            { name: "التفاصيل", value: `\`\`\`${details}\`\`\`` },
            { name: "ملاحظات", value: note }
          )
          .setFooter({ text: `Order ID: ${interaction.id}` })
          .setTimestamp();

        await targetRoom
          .send({
            content: roleId ? `<@&${roleId}>` : undefined,
            embeds: [embed],
          })
          .catch(() => null);

        return interaction.editReply({
          content: `**✅ تم إرسال طلبك بنجاح، سيتم التواصل معك قريبًا في ${targetRoom}.**`,
        });
      }
    } catch (error) {
      console.error(`[Commerce] خطأ في معالج السلكت/المودال:`, error);
      if (interaction.deferred || interaction.replied) {
        await interaction
          .followUp({ content: "**حدث خطأ أثناء تنفيذ الطلب.**", ephemeral: true })
          .catch(() => {});
      } else if (interaction.isRepliable && interaction.isRepliable()) {
        await interaction
          .reply({ content: "**حدث خطأ أثناء تنفيذ الطلب.**", ephemeral: true })
          .catch(() => {});
      }
    }
  });
};
