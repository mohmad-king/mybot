/**
 * ==========================================
 * Commerce Bot - بوت التجارة الموحّد
 * يدمج: credit + orders + offer + tax + come
 * ==========================================
 */
const { Client, Collection, GatewayIntentBits, Partials } = require("discord.js");
const { Database } = require("st.db");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

// دمج جميع توكنات البوتات السابقة
const creditList    = tokens.get("credit")    || [];
const ordersList    = tokens.get("orders")    || [];
const offerList     = tokens.get("offer")     || [];
const taxList       = tokens.get("tax")       || [];
const comeList      = tokens.get("come")      || [];

// توحيد القوائم تحت مفتاح "commerce"
// (في حال اشترى أحد commerce جديد)
const commerceList  = tokens.get("commerce")  || [];

const mergedCommerceTokens = [
  ...creditList,
  ...ordersList,
  ...offerList,
  ...taxList,
  ...comeList,
  ...commerceList,
];

// إزالة التكرار حسب التوكن: نفس البوت ممكن يكون مسجّل في أكثر
// من قائمة قديمة (مثلاً عنده orders و offer سوا على نفس التوكن).
// بدون هذا الفلتر بيتم إنشاء أكثر من Client بنفس التوكن، وكل Client
// يركّب معالج تفاعلات (ordersSelectHandler) خاص به، فيتسابقوا على
// الرد على نفس الـ interaction ويظهر للمستخدم "This interaction failed".
const seenCommerceTokens = new Set();
const allCommerceTokens = mergedCommerceTokens.filter((data) => {
  if (!data?.token) return false;
  if (seenCommerceTokens.has(data.token)) return false;
  seenCommerceTokens.add(data.token);
  return true;
});

if (!allCommerceTokens || allCommerceTokens.length === 0) return;

allCommerceTokens.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const clientCommerce = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  clientCommerce.commands = new Collection();
  clientCommerce.events = new Collection();
  clientCommerce.setMaxListeners(200);

  require("./handlers/events")(clientCommerce);
  require("./handlers/ordersSelectHandler")(clientCommerce);

  // تحميل الأوامر من مجلد slashcommand_commerce
  const commerceSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand_commerce");
  clientCommerce.commerceSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          commerceSlashCommands.push(command.data.toJSON());
          clientCommerce.commerceSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[Commerce] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  clientCommerce.once("ready", async () => {
    console.log(`[Commerce] ✅ ${clientId} شغال`);
    try {
      await rest.put(Routes.applicationCommands(clientCommerce.user.id), { body: commerceSlashCommands });
    } catch (err) {
      console.error(`[Commerce] خطأ تسجيل الأوامر:`, err.message);
    }
  });

  clientCommerce.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = clientCommerce.commerceSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, clientCommerce);
    } catch (err) {
      console.error(`[Commerce] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  await clientCommerce.login(token)
    .then(() => liveBots.set(token, clientCommerce))
    .catch(async () => {
      console.log(`[Commerce] ${clientId} توكن خاطئ وتم تخطيه`);
    });
});
