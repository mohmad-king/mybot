const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const ticketDB = new Database("Json-db/Bots/ticketDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const ticketList = tokens.get("ticket");
if (!ticketList || ticketList.length === 0) return;

ticketList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client7 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client7.commands = new Collection();
  client7.events = new Collection();
  client7.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client7);
  require(`./handlers/ticketClaim`)(client7);
  require(`./handlers/ticketCreate`)(client7);
  require(`./handlers/ticketDelete`)(client7);
  require(`./handlers/ticketSubmitCreate`)(client7);
  require(`./handlers/ticketUnclaim`)(client7);
  require(`./handlers/comeButton`)(client7);
  require(`./handlers/reset`)(client7);
  require(`./handlers/supportTicketPanel`)(client7);
  require("../../events/requireBots/ticket-commands")(client7);

  // ── تحميل الأوامر ──
  const ticketSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand7");
  client7.ticketSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          ticketSlashCommands.push(command.data.toJSON());
          client7.ticketSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[ticket] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client7.once("ready", async () => {
    console.log(`[ticket] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client7.user.id), { body: ticketSlashCommands });
    } catch (err) {
      console.error(`[ticket] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client7.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client7.ticketSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client7);
    } catch (err) {
      console.error(`[ticket] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client7.login(token)
    .then(() => liveBots.set(token, client7))
    .catch(async () => {
      const list = tokens.get("ticket") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("ticket", filtered);
      console.log(`[ticket] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
