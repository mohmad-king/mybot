const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const path = require("path");
const quranDB = new Database("Json-db/Bots/quranDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const quranList = tokens.get("quran");
if (!quranList || quranList.length === 0) return;

quranList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client26 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client26.commands = new Collection();
  client26.events = new Collection();
  client26.setMaxListeners(200);

  require("./handlers/events")(client26);

  require("../../events/requireBots/quran-commands")(client26);

  const quranSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand26");
  client26.quranSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          quranSlashCommands.push(command.data.toJSON());
          client26.quranSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[quran] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client26.once("ready", async () => {
    console.log(`[quran] ✅ ${clientId} شغال`);

    try {
      await rest.put(Routes.applicationCommands(client26.user.id), { body: quranSlashCommands });
    } catch (err) {
      console.error(`[quran] خطأ تسجيل الأوامر:`, err.message);
    }
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js

  });

  client26.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client26.quranSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client26);
    } catch (err) {
      console.error(`[quran] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  await client26.login(token)
    .then(() => liveBots.set(token, client26))
    .catch(async () => {
      const list = tokens.get("quran") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("quran", filtered);
      console.log(`[quran] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
