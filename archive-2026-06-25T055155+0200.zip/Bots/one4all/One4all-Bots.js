const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const one4allDB = new Database("Json-db/Bots/one4allDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const one4allList = tokens.get("one4all");
if (!one4allList || one4allList.length === 0) return;

one4allList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client27 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client27.commands = new Collection();
  client27.events = new Collection();
  client27.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client27);

  require("../../events/requireBots/One4all-Commands")(client27);

  // ── تحميل الأوامر ──
  const one4allSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand27");
  client27.one4allSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          one4allSlashCommands.push(command.data.toJSON());
          client27.one4allSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[one4all] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client27.once("ready", async () => {
    console.log(`[one4all] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client27.user.id), { body: one4allSlashCommands });
    } catch (err) {
      console.error(`[one4all] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client27.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client27.one4allSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client27);
    } catch (err) {
      console.error(`[one4all] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client27.login(token)
    .then(() => liveBots.set(token, client27))
    .catch(async () => {
      const list = tokens.get("one4all") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("one4all", filtered);
      console.log(`[one4all] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
