const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const sellerDB = new Database("Json-db/Bots/sellerDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const sellerList = tokens.get("seller");
if (!sellerList || sellerList.length === 0) return;

sellerList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client50 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client50.commands = new Collection();
  client50.events = new Collection();
  client50.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client50);

  require("../../events/requireBots/seller-commands")(client50);

  // ── تحميل الأوامر ──
  const sellerSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand50");
  client50.sellerSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          sellerSlashCommands.push(command.data.toJSON());
          client50.sellerSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[seller] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client50.once("ready", async () => {
    console.log(`[seller] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client50.user.id), { body: sellerSlashCommands });
    } catch (err) {
      console.error(`[seller] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client50.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client50.sellerSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client50);
    } catch (err) {
      console.error(`[seller] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client50.login(token)
    .then(() => liveBots.set(token, client50))
    .catch(async () => {
      const list = tokens.get("seller") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("seller", filtered);
      console.log(`[seller] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
