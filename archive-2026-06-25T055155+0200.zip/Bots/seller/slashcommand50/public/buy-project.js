// ═══════════════════════════════════════════════════════════════
//  buy-project.js  —  بوت البيع (seller)
//
//  النظام:
//  - العميل يختار بروجكت ويحوّل الكريدت
//  - قبل إتمام البيع يتحقق النظام من رصيد كوينز الميكر
//  - إذا الميكر ما عنده كوينز → يوقف العملية ويطلب منه يعبّي
//  - إذا عنده كوينز → يخصم 1 كوين ويكمل العملية
// ═══════════════════════════════════════════════════════════════
const {
  SlashCommandBuilder,
  EmbedBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require("discord.js");
const { Database } = require("st.db");

const db        = new Database("Json-db/Bots/sellerDB.json");
const usersdata = new Database("database/usersdata/usersdata");
const tokens    = new Database("tokens/tokens");

// كم كوين يُخصم لكل عملية بيع ناجحة (تقدر تغيّرها)
const COINS_PER_SALE = 1;

module.exports = {
  ownersOnly: false,
  data: new SlashCommandBuilder()
    .setName("buy-project")
    .setDescription("شراء بروجكت"),

  async execute(interaction) {
    const guildId = interaction.guild.id;

    // ── 0. تحقق البلاك ليست ──
    const bannedUsers = db.get(`BannedUsers_${guildId}`) ?? [];
    if (bannedUsers.includes(interaction.user.id)) {
      return interaction.reply({
        content: "**لا يمكنك استخدام هذا الأمر لأنك في القائمة السوداء.**",
        ephemeral: true,
      });
    }

    // ── 1. جلب المنتجات ──
    const products = await db.get(`Products_${guildId}`);
    if (!products || products.length === 0) {
      return interaction.reply({ content: "**لا يوجد أي بروجكت حاليا**", ephemeral: true });
    }

    // ── 2. جلب معلومات الميكر (owner) من tokens ──
    const sellerList = tokens.get("seller") ?? [];
    const sellerEntry = sellerList.find(s => s.guildid === guildId);
    const ownerId = sellerEntry?.owner ?? null;

    // ── 3. التحقق من كوينز الميكر قبل إظهار المنيو ──
    if (ownerId) {
      const ownerCoins = parseInt(usersdata.get(`balance_${ownerId}_${guildId}`)) || 0;
      if (ownerCoins < COINS_PER_SALE) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setTitle("⛔ البوت لا يملك كوينز كافية")
              .setDescription(
                `**لا يمكن إتمام أي عملية شراء حالياً.**\n` +
                `> رصيد البوت من الكوينز: \`${ownerCoins}\`\n\n` +
                `📌 على صاحب البوت شراء كوينز أولاً عبر \`/buy-coins\` في **سيرفر الرئيسي**.`
              )
              .setColor("Red")
              .setTimestamp(),
          ],
          ephemeral: true,
        });
      }
    }

    // ── 4. إظهار منيو البروجكتات ──
    const image =
      (await db.get(`image_${guildId}`)) ??
      "https://media.discordapp.net/attachments/1230863987751522334/1236721732807692432/20240228_033848_2_10_19_4_12.png";

    const menuEmbed = new EmbedBuilder()
      .setDescription("**لرؤية البروجكتات الموجودة قم بفتح المنيو أسفل الرسالة**")
      .setImage(image)
      .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
      .setThumbnail(interaction.guild.iconURL())
      .setColor("#000000");

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId("buyProduct")
      .setPlaceholder("إضغط هنا لاظهار البروجكتات")
      .addOptions(products.map(p => ({ label: p.productName, value: p.productName })));

    const menuRow = new ActionRowBuilder().addComponents(selectMenu);
    const messageProduct = await interaction.reply({
      embeds: [menuEmbed],
      components: [menuRow],
      ephemeral: true,
    });

    // ── 5. الانتظار لاختيار العميل ──
    const compFilter = i => i.isMessageComponent() && i.customId === "buyProduct" && i.user.id === interaction.user.id;
    const collector = interaction.channel.createMessageComponentCollector({
      filter: compFilter,
      maxComponents: 1,
      time: 60_000,
    });

    collector.on("collect", async (i) => {
      if (i.customId !== "buyProduct") return;

      const selectedProductId = i.values[0];
      const foundProduct = products.find(p => p.productName === selectedProductId);
      if (!foundProduct) {
        return i.update({ content: "**حدث خطأ، لم يتم العثور على البروجكت.**", embeds: [], components: [] });
      }

      const { productPrice, productLink } = foundProduct;
      const price2 = parseFloat(productPrice);
      const price3 = Math.floor(price2 * (20 / 19) + 1);

      // ── 6. إعادة التحقق من كوينز الميكر لحظة الشراء الفعلي ──
      if (ownerId) {
        const ownerCoins = parseInt(usersdata.get(`balance_${ownerId}_${guildId}`)) || 0;
        if (ownerCoins < COINS_PER_SALE) {
          return messageProduct.edit({
            content: "",
            embeds: [
              new EmbedBuilder()
                .setTitle("⛔ البوت نفذت كوينزه")
                .setDescription(
                  `**نفذت كوينز البوت أثناء عملية الشراء. لا يمكن إتمام العملية.**\n` +
                  `> اذهب إلى **إعادة تعبئة البوت** واطلب من المسؤول إضافة كوينز.`
                )
                .setColor("Red")
                .setTimestamp(),
            ],
            components: [],
          });
        }
      }

      // ── 7. إظهار أمر التحويل ──
      const BankId      = await db.get(`BankId_${guildId}`);
      const ProBotId    = await db.get(`ProBotId_${guildId}`);
      const transferroom = await db.get(`transferroom_${guildId}`);

      await messageProduct.edit({
        content: `**يجب عليك التحويل في أسرع وقت**\n\`\`\`#credit ${BankId} ${price3}\`\`\``,
        embeds: [],
        components: [],
      });

      const transferRoom = interaction.guild.channels.cache.find(ch => ch.id === transferroom);
      if (!transferRoom) {
        return messageProduct.edit({ content: "**لم يتم إعداد روم التحويل. تواصل مع الأدمن.**", embeds: [], components: [] });
      }

      const msgFilter = m =>
        m.author.bot &&
        m.author.id === String(ProBotId) &&
        m.content.includes(":moneybag:") &&
        m.content.split("$").slice(-1)[0].split("`")[0] == String(price2) &&
        m.mentions.members?.first()?.id === String(BankId);

      try {
        await transferRoom.awaitMessages({ filter: msgFilter, max: 1, time: 300_000, errors: ["time"] });

        // ── 8. التحويل تم ← خصم كوين من الميكر ──
        if (ownerId) {
          const ownerCoins = parseInt(usersdata.get(`balance_${ownerId}_${guildId}`)) || 0;
          const newOwnerCoins = Math.max(0, ownerCoins - COINS_PER_SALE);
          await usersdata.set(`balance_${ownerId}_${guildId}`, newOwnerCoins);
          console.log(`[seller] خُصم ${COINS_PER_SALE} كوين من ميكر ${ownerId} — رصيده الجديد: ${newOwnerCoins}`);
        }

        // ── 9. إرسال البروجكت للعميل ──
        try {
          await interaction.user.send({ content: `**البروجكت: ${productLink}**` });
          await messageProduct.edit({ content: "**تم إرسال البروجكت إلى خاصك بنجاح ✅**", embeds: [], components: [] });
        } catch {
          await messageProduct.edit({
            content: "**خاصك مقفل! لم أستطع إرسال البروجكت. تواصل مع الأونر للحصول عليه.**",
            embeds: [],
            components: [],
          });
        }

        // ── 10. إضافة رتبة العميل ──
        const roleID = db.get(`role_${guildId}`);
        if (roleID) {
          const theRole = interaction.guild.roles.cache.get(roleID);
          if (theRole) {
            await interaction.guild.members.cache
              .get(interaction.user.id)
              ?.roles.add(theRole)
              .catch(() => {});
          }
        }

        // ── 11. لوج في السيرفر ──
        const logChannelId = db.get(`log_${guildId}`);
        const logChannel   = interaction.guild.channels.cache.get(logChannelId);
        if (logChannel) {
          const ownerCoinsLeft = ownerId
            ? parseInt(usersdata.get(`balance_${ownerId}_${guildId}`)) || 0
            : "—";
          const logEmbed = new EmbedBuilder()
            .setColor("Green")
            .setDescription(
              `**✅ تم شراء \`${selectedProductId}\` بواسطة ${interaction.user}**\n` +
              `> 💰 كوينز البوت المتبقية: \`${ownerCoinsLeft}\``
            )
            .setTimestamp();
          logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      } catch {
        // انتهى الوقت
        await messageProduct.edit({ content: "**تم إلغاء العملية — انتهى الوقت.**", embeds: [], components: [] });
      }
    });

    collector.on("end", async (_, reason) => {
      if (reason === "time") {
        await messageProduct.edit({ content: "**تم إلغاء العملية.**", embeds: [], components: [] }).catch(() => {});
      }
    });
  },
};
