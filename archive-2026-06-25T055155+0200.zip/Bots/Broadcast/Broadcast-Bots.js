const { Client, Collection, GatewayIntentBits, Partials } = require("discord.js");
const { Database } = require("st.db");
const BroadcastDB = new Database("Json-db/Bots/BroadcastDB.json");
const NormalBroadcastDB = new Database("Json-db/Bots/NormalBroadcastDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

// ─────────────────────────────────────────
// 📡 بوت Broadcast (بانل + أزرار)
// ─────────────────────────────────────────
const BroadcastList = tokens.get("Broadcast");
if (BroadcastList && BroadcastList.length > 0) {
  BroadcastList.forEach(async (data) => {
    const { token, clientId, owner } = data;

    const client2 = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
      ],
      partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
    });

    client2.commands = new Collection();
    client2.events = new Collection();
    client2.setMaxListeners(200);

    require("./handlers/events")(client2);
    require("../../events/requireBots/Broadcast-commands")(client2);

    const BroadcastSlashCommands = [];
    const folderPath = path.join(__dirname, "slashcommand2");
    client2.BroadcastSlashCommands = new Collection();

    try {
      for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
        for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
          const command = require(`${folderPath}/${folder}/${file}`);
          if (command?.data?.name) {
            BroadcastSlashCommands.push(command.data.toJSON());
            client2.BroadcastSlashCommands.set(command.data.name, command);
          }
        }
      }
    } catch (err) {
      console.error(`[Broadcast] خطأ في تحميل الأوامر:`, err.message);
    }

    const rest = new REST({ version: "10" }).setToken(token);

    client2.once("ready", async () => {
      console.log(`[Broadcast] ✅ ${clientId} شغال`);
      try {
        await rest.put(Routes.applicationCommands(client2.user.id), { body: BroadcastSlashCommands });
      } catch (err) {
        console.error(`[Broadcast] خطأ تسجيل الأوامر:`, err.message);
      }
    });

    client2.on("interactionCreate", async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.user.bot) return;
      const command = client2.BroadcastSlashCommands.get(interaction.commandName);
      if (!command) return;
      if (command.ownersOnly === true && owner !== interaction.user.id) {
        return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
      }
      try {
        await command.execute(interaction, client2);
      } catch (err) {
        console.error(`[Broadcast] خطأ في الامر ${interaction.commandName}:`, err.message);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
        } else {
          await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
        }
      }
    });

    await client2.login(token)
      .then(() => liveBots.set(token, client2))
      .catch(async () => {
        const list = tokens.get("Broadcast") || [];
        const filtered = list.filter(b => b.token !== token);
        await tokens.set("Broadcast", filtered);
        console.log(`[Broadcast] ${clientId} توكن خاطئ وتم حذفه`);
      });
  });
}

// ─────────────────────────────────────────
// 📢 بوت NormalBroadcast (أمر /bc مباشر)
// ─────────────────────────────────────────
const Broadcast2List = tokens.get("Broadcast2");
if (Broadcast2List && Broadcast2List.length > 0) {
  Broadcast2List.forEach(async (data) => {
    const { token, clientId, owner } = data;

    const client18 = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
      ],
      partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
    });

    client18.commands = new Collection();
    client18.events = new Collection();
    client18.setMaxListeners(200);

    require("./handlers/events")(client18);
    require("../../events/requireBots/normal-broadcast-commands")(client18);

    const NormalBroadcastSlashCommands = [];
    const folderPath2 = path.join(__dirname, "slashcommand2", "Admin2");
    client18.NormalBroadcastSlashCommands = new Collection();

    try {
      for (const file of readdirSync(folderPath2).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath2}/${file}`);
        if (command?.data?.name) {
          NormalBroadcastSlashCommands.push(command.data.toJSON());
          client18.NormalBroadcastSlashCommands.set(command.data.name, command);
        }
      }
    } catch (err) {
      console.error(`[NormalBroadcast] خطأ في تحميل الأوامر:`, err.message);
    }

    const rest = new REST({ version: "10" }).setToken(token);

    client18.once("ready", async () => {
      console.log(`[NormalBroadcast] ✅ ${clientId} شغال`);
      try {
        await rest.put(Routes.applicationCommands(client18.user.id), { body: NormalBroadcastSlashCommands });
      } catch (err) {
        console.error(`[NormalBroadcast] خطأ تسجيل الأوامر:`, err.message);
      }
    });

    client18.on("interactionCreate", async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      if (interaction.user.bot) return;
      const command = client18.NormalBroadcastSlashCommands.get(interaction.commandName);
      if (!command) return;
      if (command.ownersOnly === true && owner !== interaction.user.id) {
        return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
      }
      try {
        await command.execute(interaction, client18);
      } catch (err) {
        console.error(`[NormalBroadcast] خطأ في الامر ${interaction.commandName}:`, err.message);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
        } else {
          await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
        }
      }
    });

    await client18.login(token)
      .then(() => liveBots.set(token, client18))
      .catch(async () => {
        const list = tokens.get("Broadcast2") || [];
        const filtered = list.filter(b => b.token !== token);
        await tokens.set("Broadcast2", filtered);
        console.log(`[NormalBroadcast] ${clientId} توكن خاطئ وتم حذفه`);
      });
  });
}
