const path = require('path');
const { readdirSync } = require('fs');

module.exports = (client) => {
  const eventsDir = path.join(__dirname, '../events/');
  const files = readdirSync(eventsDir).filter(f => f.endsWith('.js'));

  for (const file of files) {
    try {
      const pull = require(path.join(eventsDir, file));

      // النمط الجديد: module.exports = { name, execute }
      if (pull.name && typeof pull.execute === 'function') {
        client.on(pull.name, (...args) => pull.execute(...args, client));
        continue;
      }

      // النمط القديم: module.exports.run = async (client, ...) => {}
      const eventName = pull.event || file.replace('.js', '');
      if (typeof pull.run === 'function') {
        client.on(eventName, pull.run.bind(null, client));
      }
    } catch (err) {
      console.error(`[events handler] خطأ في تحميل ${file}:`, err.message);
    }
  }
};
