const { Events } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("Json-db/Bots/marketstoreDB.json");

module.exports = (client) => {
  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId !== "update-item") return;

    const oldName  = interaction.fields.getTextInputValue("oldName");
    const newName  = interaction.fields.getTextInputValue("newName");
    const newPrice = interaction.fields.getTextInputValue("newPrice");
    const newLink  = interaction.fields.getTextInputValue("newLink");

    if (isNaN(newPrice))
      return interaction.reply({ content: "**قم بإدخال سعر المنتج بطريقة صحيحة.**", ephemeral: true });

    const items = await db.get(`items_${interaction.guild.id}`) || [];
    const target = items.find(i => i.itemName === oldName);

    if (!target)
      return interaction.reply({ content: "**قم بإدخال اسم منتج صحيح.**", ephemeral: true });

    const updated = items.filter(i => i.itemName !== oldName);
    updated.push({ itemName: newName, itemPrice: newPrice, itemLink: newLink, itemType: target.itemType });
    await db.set(`items_${interaction.guild.id}`, updated);

    interaction.reply({ content: "**✅ تم تعديل المنتج بنجاح.**" });
  });
};
