const { Events } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("Json-db/Bots/marketstoreDB.json");

module.exports = (client) => {
  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId !== "add_pool_goods") return;

    const productName = interaction.fields.getTextInputValue("product_name");
    const goodsList   = interaction.fields.getTextInputValue("goods_list");
    const g           = interaction.guild.id;

    const products = await db.get(`pool_products_${g}`) || [];
    const product  = products.find(p => p.name === productName);

    if (!product)
      return interaction.reply({ content: `**لا يوجد منتج باسم "${productName}". أضفه أولاً بـ /add-pool-product**`, ephemeral: true });

    // كل سطر = سلعة واحدة
    const newGoods = goodsList.split("\n").map(s => s.trim()).filter(s => s.length > 0);
    product.goods.push(...newGoods);
    await db.set(`pool_products_${g}`, products);

    interaction.reply({ content: `**✅ تم إضافة ${newGoods.length} سلعة لمنتج "${productName}" بنجاح.**`, ephemeral: true });
  });
};
