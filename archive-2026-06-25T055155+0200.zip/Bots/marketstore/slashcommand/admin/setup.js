const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("Json-db/Bots/marketstoreDB.json");

module.exports = {
  ownersOnly: true,
  data: new SlashCommandBuilder()
    .setName("setup")
    .setDescription("إعداد البوت (روم اللوج، التحويل، رتبة العميل، صورة البانل)")
    .addChannelOption(o => o.setName("log-channel").setDescription("روم تم الشراء").setRequired(false))
    .addChannelOption(o => o.setName("transfer-room").setDescription("روم التحويل").setRequired(false))
    .addRoleOption(o => o.setName("customer").setDescription("رتبة العميل").setRequired(false))
    .addStringOption(o => o.setName("panel-image").setDescription("صورة البانل").setRequired(false)),

  async execute(interaction) {
    const log      = interaction.options.getChannel("log-channel");
    const transfer = interaction.options.getChannel("transfer-room");
    const role     = interaction.options.getRole("customer");
    const image    = interaction.options.getString("panel-image");
    const g        = interaction.guild.id;

    if (log)      db.set(`log_${g}`, log.id);
    if (transfer) db.set(`transferroom_${g}`, transfer.id);
    if (role)     db.set(`role_${g}`, role.id);
    if (image)    db.set(`image_${g}`, image);

    interaction.reply({ content: "**✅ تم حفظ الإعدادات بنجاح.**", ephemeral: true });
  },
};
