const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("Json-db/Bots/marketstoreDB.json");

module.exports = {
  ownersOnly: true,
  data: new SlashCommandBuilder()
    .setName("delete-item")
    .setDescription("حذف منتج من المتجر")
    .addStringOption(o => o.setName("item-name").setDescription("اسم المنتج المراد حذفه").setRequired(true)),

  async execute(interaction) {
    const itemName = interaction.options.getString("item-name");
    const items    = await db.get(`items_${interaction.guild.id}`) || [];
    const target   = items.find(i => i.itemName === itemName);

    if (!target)
      return interaction.reply({ content: "**لا يوجد منتج بهذا الاسم.**", ephemeral: true });

    await db.set(`items_${interaction.guild.id}`, items.filter(i => i.itemName !== itemName));
    interaction.reply({ content: `**✅ تم حذف "${itemName}" بنجاح.**`, ephemeral: true });
  },
};
