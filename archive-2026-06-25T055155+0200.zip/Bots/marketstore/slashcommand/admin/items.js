const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("Json-db/Bots/marketstoreDB.json");

module.exports = {
  ownersOnly: true,
  data: new SlashCommandBuilder()
    .setName("items")
    .setDescription("عرض كل المنتجات في المتجر")
    .addStringOption(o => o.setName("type").setDescription("تصفية حسب النوع (اختياري)")
      .setRequired(false)
      .addChoices(
        { name: "كود",     value: "كود"    },
        { name: "بروجكت", value: "بروجكت" },
        { name: "أداة",   value: "أداة"   }
      )),

  async execute(interaction) {
    const type  = interaction.options.getString("type");
    const items = await db.get(`items_${interaction.guild.id}`) || [];
    const list  = type ? items.filter(i => i.itemType === type) : items;

    if (list.length === 0)
      return interaction.reply({ content: "**لا يوجد أي منتجات حالياً.**", ephemeral: true });

    const desc = list.map((i, n) =>
      `**${n + 1}.** ${i.itemType} | **${i.itemName}** — ${i.itemPrice} 💰`
    ).join("\n");

    const embed = new EmbedBuilder()
      .setTitle(`📦 منتجات المتجر${type ? ` (${type})` : ""}`)
      .setDescription(desc)
      .setColor("#000000");

    interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
