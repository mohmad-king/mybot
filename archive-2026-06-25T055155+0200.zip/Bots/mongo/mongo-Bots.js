const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const mongoDB = new Database("Json-db/Bots/mongoDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const mongoList = tokens.get("mongo");
if (!mongoList || mongoList.length === 0) return;

mongoList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client200 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client200.commands = new Collection();
  client200.events = new Collection();
  client200.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client200);

  require("../../events/requireBots/mongo-commands")(client200);

  // ── تحميل الأوامر ──
  const mongoSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand200");
  client200.mongoSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          mongoSlashCommands.push(command.data.toJSON());
          client200.mongoSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[mongo] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client200.once("ready", async () => {
    console.log(`[mongo] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client200.user.id), { body: mongoSlashCommands });
    } catch (err) {
      console.error(`[mongo] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client200.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client200.mongoSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client200);
    } catch (err) {
      console.error(`[mongo] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client200.login(token)
    .then(() => liveBots.set(token, client200))
    .catch(async () => {
      const list = tokens.get("mongo") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("mongo", filtered);
      console.log(`[mongo] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
