const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const scammersDB = new Database("Json-db/Bots/scammersDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const scammersList = tokens.get("scammers");
if (!scammersList || scammersList.length === 0) return;

scammersList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client4 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client4.commands = new Collection();
  client4.events = new Collection();
  client4.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client4);

  require("../../events/requireBots/Scammers-commands")(client4);

  // ── تحميل الأوامر ──
  const scammersSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand4");
  client4.scammersSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          scammersSlashCommands.push(command.data.toJSON());
          client4.scammersSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[scammers] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client4.once("ready", async () => {
    console.log(`[scammers] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client4.user.id), { body: scammersSlashCommands });
    } catch (err) {
      console.error(`[scammers] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client4.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client4.scammersSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client4);
    } catch (err) {
      console.error(`[scammers] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client4.login(token)
    .then(() => liveBots.set(token, client4))
    .catch(async () => {
      const list = tokens.get("scammers") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("scammers", filtered);
      console.log(`[scammers] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
