const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const rolesDB = new Database("Json-db/Bots/rolesDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const rolesList = tokens.get("roles");
if (!rolesList || rolesList.length === 0) return;

rolesList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client25 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client25.commands = new Collection();
  client25.events = new Collection();
  client25.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client25);

  require("../../events/requireBots/roles-commands")(client25);

  // ── تحميل الأوامر ──
  const rolesSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand25");
  client25.rolesSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          rolesSlashCommands.push(command.data.toJSON());
          client25.rolesSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[roles] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client25.once("ready", async () => {
    console.log(`[roles] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client25.user.id), { body: rolesSlashCommands });
    } catch (err) {
      console.error(`[roles] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client25.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client25.rolesSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client25);
    } catch (err) {
      console.error(`[roles] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client25.login(token)
    .then(() => liveBots.set(token, client25))
    .catch(async () => {
      const list = tokens.get("roles") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("roles", filtered);
      console.log(`[roles] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
