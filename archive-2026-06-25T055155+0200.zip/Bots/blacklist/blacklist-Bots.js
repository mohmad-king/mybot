const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const blacklistDB = new Database("Json-db/Bots/blacklistDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const blacklistList = tokens.get("blacklist");
if (!blacklistList || blacklistList.length === 0) return;

blacklistList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client8 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client8.commands = new Collection();
  client8.events = new Collection();
  client8.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client8);

  require("../../events/requireBots/blacklist-commands")(client8);

  // ── تحميل الأوامر ──
  const blacklistSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand8");
  client8.blacklistSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          blacklistSlashCommands.push(command.data.toJSON());
          client8.blacklistSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[blacklist] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client8.once("ready", async () => {
    console.log(`[blacklist] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client8.user.id), { body: blacklistSlashCommands });
    } catch (err) {
      console.error(`[blacklist] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client8.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client8.blacklistSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client8);
    } catch (err) {
      console.error(`[blacklist] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client8.login(token)
    .then(() => liveBots.set(token, client8))
    .catch(async () => {
      const list = tokens.get("blacklist") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("blacklist", filtered);
      console.log(`[blacklist] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
