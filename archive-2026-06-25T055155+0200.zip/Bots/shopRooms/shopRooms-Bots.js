const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const shopRoomsDB = new Database("Json-db/Bots/shopRoomsDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const shopRoomsList = tokens.get("shopRooms");
if (!shopRoomsList || shopRoomsList.length === 0) return;

shopRoomsList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client24 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client24.commands = new Collection();
  client24.events = new Collection();
  client24.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client24);

  require("../../events/requireBots/shopRooms-commands")(client24);

  // ── تحميل الأوامر ──
  const shopRoomsSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand24");
  client24.shopRoomsSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          shopRoomsSlashCommands.push(command.data.toJSON());
          client24.shopRoomsSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[shopRooms] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client24.once("ready", async () => {
    console.log(`[shopRooms] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client24.user.id), { body: shopRoomsSlashCommands });
    } catch (err) {
      console.error(`[shopRooms] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client24.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client24.shopRoomsSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client24);
    } catch (err) {
      console.error(`[shopRooms] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client24.login(token)
    .then(() => liveBots.set(token, client24))
    .catch(async () => {
      const list = tokens.get("shopRooms") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("shopRooms", filtered);
      console.log(`[shopRooms] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
