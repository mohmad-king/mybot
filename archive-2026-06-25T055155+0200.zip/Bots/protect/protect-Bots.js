const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const protectDB = new Database("Json-db/Bots/protectDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const protectList = tokens.get("protect");
if (!protectList || protectList.length === 0) return;

protectList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client19 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client19.commands = new Collection();
  client19.events = new Collection();
  client19.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client19);

  require("../../events/requireBots/protect-commands")(client19);

  // ── تحميل الأوامر ──
  const protectSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand19");
  client19.protectSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          protectSlashCommands.push(command.data.toJSON());
          client19.protectSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[protect] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client19.once("ready", async () => {
    console.log(`[protect] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client19.user.id), { body: protectSlashCommands });
    } catch (err) {
      console.error(`[protect] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client19.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client19.protectSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client19);
    } catch (err) {
      console.error(`[protect] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client19.login(token)
    .then(() => liveBots.set(token, client19))
    .catch(async () => {
      const list = tokens.get("protect") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("protect", filtered);
      console.log(`[protect] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
