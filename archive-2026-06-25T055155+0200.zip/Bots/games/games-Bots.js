const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const gamesDB = new Database("Json-db/Bots/gamesDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const gamesList = tokens.get("games");
if (!gamesList || gamesList.length === 0) return;

gamesList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client26 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client26.commands = new Collection();
  client26.events = new Collection();
  client26.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client26);

  require("../../events/requireBots/games-commands")(client26);

  // ── تحميل الأوامر ──
  const gamesSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand26");
  client26.gamesSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          gamesSlashCommands.push(command.data.toJSON());
          client26.gamesSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[games] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client26.once("ready", async () => {
    console.log(`[games] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client26.user.id), { body: gamesSlashCommands });
    } catch (err) {
      console.error(`[games] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client26.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client26.gamesSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client26);
    } catch (err) {
      console.error(`[games] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client26.login(token)
    .then(() => liveBots.set(token, client26))
    .catch(async () => {
      const list = tokens.get("games") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("games", filtered);
      console.log(`[games] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
