const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const tokenDB = new Database("/Json-db/Bots/tokenDB.json");
const tokens = new Database("/tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const tokenList = tokens.get("token");
if (!tokenList || tokenList.length === 0) return;

tokenList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client300 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client300.commands = new Collection();
  client300.events = new Collection();
  client300.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client300);

  require("../../events/requireBots/token-commands")(client300);

  // ── تحميل الأوامر ──
  const tokenSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand300");
  client300.tokenSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          tokenSlashCommands.push(command.data.toJSON());
          client300.tokenSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[token] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client300.once("ready", async () => {
    console.log(`[token] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client300.user.id), { body: tokenSlashCommands });
    } catch (err) {
      console.error(`[token] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client300.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client300.tokenSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client300);
    } catch (err) {
      console.error(`[token] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client300.login(token)
    .then(() => liveBots.set(token, client300))
    .catch(async () => {
      const list = tokens.get("token") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("token", filtered);
      console.log(`[token] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
