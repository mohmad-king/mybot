
const { Client, Collection, discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message } = require("discord.js");
const { Database } = require("st.db")
const tokenbotDB = new Database("/Json-db/Bots/tokenbotDB.json")
const tokens = new Database("/tokens/tokens")
const { liveBots } = require("../../utils/liveBots");

let tokenbot = tokens.get('tokenbot')
if(!tokenbot) return;

const path = require('path');
const { readdirSync } = require("fs");
tokenbot.forEach(async(data) => {
  const { REST } = require('@discordjs/rest');
  const { Routes } = require('discord-api-types/v10');
  const { prefix , token , clientId , owner } = data;
  theowner = owner
  const client400 = new Client({intents: [GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMessageTyping, GatewayIntentBits.MessageContent], shards: "auto", partials: [Partials.Message, Partials.Channel, Partials.GuildMember,]});
  client400.commands = new Collection();
  require(`./handlers/events`)(client400);
  client400.events = new Collection();
  require(`../../events/requireBots/tokenbot-commands`)(client400);
  const rest = new REST({ version: '10' }).setToken(token);
  client400.setMaxListeners(1000)

  client400.on("ready" , async() => {

      try {
        await rest.put(
          Routes.applicationCommands(client400.user.id),
          { body: tokenbotSlashCommands },
          );
          
        } catch (error) {
          console.error(error)
        }

    });
    require(`../tokenbot/handlers/events`)(client400)
  const folderPath = path.join(__dirname, 'slashcommand400');
  client400.tokenbotSlashCommands = new Collection();
  const tokenbotSlashCommands = [];
  const ascii = require("ascii-table");
  const table = new ascii("tokenbot commands").setJustify();
  for (let folder of readdirSync(folderPath).filter(
    (folder) => !folder.includes(".")
    )) {
      for (let file of readdirSync(`${folderPath}/` + folder).filter((f) =>
      f.endsWith(".js")
      )) {
        let command = require(`${folderPath}/${folder}/${file}`);
        if (command) {
          tokenbotSlashCommands.push(command.data.toJSON());
          client400.tokenbotSlashCommands.set(command.data.name, command);
          if (command.data.name) {
            table.addRow(`/${command.data.name}`, "🟢 Working");
          } else {
            table.addRow(`/${command.data.name}`, "🔴 Not Working");
          }
        }
  }
}



const folderPath2 = path.join(__dirname, 'commands400');

for(let foldeer of readdirSync(folderPath2).filter((folder) => !folder.includes("."))) {
  for(let fiee of(readdirSync(`${folderPath2}/${foldeer}`).filter((fi) => fi.endsWith(".js")))) {
    const commander = require(`${folderPath2}/${foldeer}/${fiee}`)
  }
}

require(`../../events/requireBots/tokenbot-commands`)(client400)
require("./handlers/events")(client400)

	for (let file of readdirSync(path.join(__dirname, 'events/')).filter(f => f.endsWith('.js'))) {
		const event = require(`./events/${file}`);
	if (event.once) {
		client400.once(event.name, (...args) => event.execute(...args));
	} else {
		client400.on(event.name, (...args) => event.execute(...args));
	}
	}




  client400.on("interactionCreate" , async(interaction) => {
    if (interaction.isChatInputCommand()) {
      
	    if(interaction.user.bot) return;

      
      const command = client400.tokenbotSlashCommands.get(interaction.commandName);
	    
      if (!command) {
        return;
      }
      if (command.ownersOnly === true) {
        if (owner != interaction.user.id) {
          return interaction.reply({content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true});
        }
      }
      try {

        await command.execute(interaction);
      } catch (error) {
			console.log(error)
		}
    }
  } )


client400.on("interactionCreate" , async(interaction) => {
  if(interaction.isModalSubmit()) {
    if(interaction.customId == "add_goods") {
      let type = interaction.fields.getTextInputValue(`type`)
      let Goods = interaction.fields.getTextInputValue(`Goods`)
      let products = tokenbotDB.get(`products_${interaction.guild.id}`)
      let productFind = products.find(prod => prod.name == type)
      if(!productFind) return interaction.reply({content:`**لا يوجد منتج بهذا الاسم**`})
      let goodsFind = productFind.goods;
      const embed = new EmbedBuilder()
      .setTimestamp(Date.now())
      .setColor('#000000')
      Goods = Goods.split("\n")
      Goods.filter(item => item.trim() !== '')
      await goodsFind.push(...Goods)
      productFind.goods = Goods
      await tokenbotDB.set(`products_${interaction.guild.id}` , products)
      embed.setTitle(`**[✅] تم اضافة السلع الى المنتج بنجاح**`)
      return interaction.reply({embeds:[embed]})
    }
  } 
})

   client400.login(token)
   .then(() => liveBots.set(token, client400))
   .catch(async(err) => {
    const filtered = tokenbot.filter(bo => bo != data)
			await tokens.set(`tokenbot` , filtered)
      console.log(`${clientId} Not working and removed `)
   });


})
