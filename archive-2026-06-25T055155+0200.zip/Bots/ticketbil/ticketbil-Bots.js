const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const ticketbilDB = new Database("Json-db/Bots/ticketbilDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const ticketbilList = tokens.get("ticketbil");
if (!ticketbilList || ticketbilList.length === 0) return;

ticketbilList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client00 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client00.commands = new Collection();
  client00.events = new Collection();
  client00.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client00);

  require("../../events/requireBots/ticketbil-commands")(client00);

  // ── تحميل الأوامر ──
  const ticketbilSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand00");
  client00.ticketbilSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          ticketbilSlashCommands.push(command.data.toJSON());
          client00.ticketbilSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[ticketbil] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client00.once("ready", async () => {
    console.log(`[ticketbil] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client00.user.id), { body: ticketbilSlashCommands });
    } catch (err) {
      console.error(`[ticketbil] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client00.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client00.ticketbilSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client00);
    } catch (err) {
      console.error(`[ticketbil] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client00.login(token)
    .then(() => liveBots.set(token, client00))
    .catch(async () => {
      const list = tokens.get("ticketbil") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("ticketbil", filtered);
      console.log(`[ticketbil] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
