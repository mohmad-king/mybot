const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const azkarDB = new Database("Json-db/Bots/azkarDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const azkarList = tokens.get("azkar");
if (!azkarList || azkarList.length === 0) return;

azkarList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client23 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client23.commands = new Collection();
  client23.events = new Collection();
  client23.setMaxListeners(200);

  require("./handlers/events")(client23);

  require("../../events/requireBots/azkar-commands")(client23);

  const azkarSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand23");
  client23.azkarSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          azkarSlashCommands.push(command.data.toJSON());
          client23.azkarSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[azkar] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client23.once("ready", async () => {
    console.log(`[azkar] ✅ ${clientId} شغال`);

    try {
      await rest.put(Routes.applicationCommands(client23.user.id), { body: azkarSlashCommands });
    } catch (err) {
      console.error(`[azkar] خطأ تسجيل الأوامر:`, err.message);
    }
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js

  });

  client23.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client23.azkarSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client23);
    } catch (err) {
      console.error(`[azkar] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  await client23.login(token)
    .then(() => liveBots.set(token, client23))
    .catch(async () => {
      const list = tokens.get("azkar") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("azkar", filtered);
      console.log(`[azkar] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
