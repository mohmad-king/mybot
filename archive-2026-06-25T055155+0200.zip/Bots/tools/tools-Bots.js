const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const toolsDB = new Database("Json-db/Bots/toolsDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const toolsList = tokens.get("tools");
if (!toolsList || toolsList.length === 0) return;

toolsList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client199 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client199.commands = new Collection();
  client199.events = new Collection();
  client199.setMaxListeners(200);

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client199);

  require("../../events/requireBots/tools-commands")(client199);

  // ── تحميل الأوامر ──
  const toolsSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand199");
  client199.toolsSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          toolsSlashCommands.push(command.data.toJSON());
          client199.toolsSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[tools] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client199.once("ready", async () => {
    console.log(`[tools] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client199.user.id), { body: toolsSlashCommands });
    } catch (err) {
      console.error(`[tools] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client199.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client199.toolsSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client199);
    } catch (err) {
      console.error(`[tools] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client199.login(token)
    .then(() => liveBots.set(token, client199))
    .catch(async () => {
      const list = tokens.get("tools") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("tools", filtered);
      console.log(`[tools] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
