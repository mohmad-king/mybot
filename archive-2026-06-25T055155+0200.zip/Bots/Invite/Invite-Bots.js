const { Client, Collection, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const InviteDB = new Database("Json-db/Bots/InviteDB.json");
const invitesDB = new Database("Json-db/Bots/invitesDB.json");
const tokens = new Database("tokens/tokens");
const { liveBots } = require("../../utils/liveBots");
const path = require("path");
const { readdirSync } = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v10");

const InviteList = tokens.get("Invite");
if (!InviteList || InviteList.length === 0) return;

InviteList.forEach(async (data) => {
  const { token, clientId, owner } = data;

  const client16 = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
            GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildInvites,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });

  client16.commands = new Collection();
  client16.events = new Collection();
  client16.setMaxListeners(200);

  // ── تتبع الدعوات (إحصاء joins/leaves لكل عضو) ──
  const invitesCache = new Collection();

  client16.once("ready", async () => {
    for (const guild of client16.guilds.cache.values()) {
      const invites = await guild.invites.fetch().catch(() => null);
      if (invites) invitesCache.set(guild.id, invites);
    }
  });

  client16.on("inviteCreate", async (invite) => {
    const invites = await invite.guild.invites.fetch().catch(() => null);
    if (invites) invitesCache.set(invite.guild.id, invites);
  });

  client16.on("guildMemberAdd", async (member) => {
    try {
      const guildId = member.guild.id;
      const newInvites = await member.guild.invites.fetch().catch(() => null);
      if (!newInvites) return;

      const oldInvites = invitesCache.get(guildId) || new Collection();
      invitesCache.set(guildId, newInvites);

      const usedInvite = newInvites.find((inv) => {
        const oldUses = oldInvites.get(inv.code)?.uses || 0;
        return inv.uses > oldUses;
      });

      if (usedInvite && usedInvite.inviter) {
        const inviterId = usedInvite.inviter.id;
        invitesDB.add(`invites_${guildId}_${inviterId}_joined`, 1);
        invitesDB.set(`invitedBy_${guildId}_${member.id}`, inviterId);
      }
    } catch (err) {
      console.error(`[Invite] خطأ في تتبع انضمام عضو:`, err.message);
    }
  });

  client16.on("guildMemberRemove", async (member) => {
    try {
      const guildId = member.guild.id;
      const inviterId = invitesDB.get(`invitedBy_${guildId}_${member.id}`);
      if (inviterId) {
        invitesDB.add(`invites_${guildId}_${inviterId}_left`, 1);
      }
    } catch (err) {
      console.error(`[Invite] خطأ في تتبع مغادرة عضو:`, err.message);
    }
  });

  // ── تحميل الـ handlers ──
  require("./handlers/events")(client16);

  require("../../events/requireBots/Invite-commands")(client16);

  // ── تحميل الأوامر ──
  const InviteSlashCommands = [];
  const folderPath = path.join(__dirname, "slashcommand16");
  client16.InviteSlashCommands = new Collection();

  try {
    for (const folder of readdirSync(folderPath).filter(f => !f.includes("."))) {
      for (const file of readdirSync(`${folderPath}/${folder}`).filter(f => f.endsWith(".js"))) {
        const command = require(`${folderPath}/${folder}/${file}`);
        if (command?.data?.name) {
          InviteSlashCommands.push(command.data.toJSON());
          client16.InviteSlashCommands.set(command.data.name, command);
        }
      }
    }
  } catch (err) {
    console.error(`[Invite] خطأ في تحميل الأوامر:`, err.message);
  }

  const rest = new REST({ version: "10" }).setToken(token);

  client16.once("ready", async () => {
    console.log(`[Invite] ✅ ${clientId} شغال`);

    // تسجيل الأوامر
    try {
      await rest.put(Routes.applicationCommands(client16.user.id), { body: InviteSlashCommands });
    } catch (err) {
      console.error(`[Invite] خطأ تسجيل الأوامر:`, err.message);
    }

    // ── فحص انتهاء الاشتراك كل دقيقة ──
  // ⬆️ فحص الاشتراك تم نقله للنظام المركزي في utils/subscriptionChecker.js
 // كل دقيقة بدل كل ثانية
  });

  // ── معالجة الأوامر ──
  client16.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.user.bot) return;

    const command = client16.InviteSlashCommands.get(interaction.commandName);
    if (!command) return;

    if (command.ownersOnly === true && owner !== interaction.user.id) {
      return interaction.reply({ content: `❗ ***لا تستطيع استخدام هذا الامر***`, ephemeral: true }).catch(() => {});
    }

    try {
      await command.execute(interaction, client16);
    } catch (err) {
      console.error(`[Invite] خطأ في الامر ${interaction.commandName}:`, err.message);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: "حدث خطأ أثناء تنفيذ الأمر.", ephemeral: true }).catch(() => {});
      }
    }
  });

  // ── تسجيل الدخول ──
  await client16.login(token)
    .then(() => liveBots.set(token, client16))
    .catch(async () => {
      const list = tokens.get("Invite") || [];
      const filtered = list.filter(b => b.token !== token);
      await tokens.set("Invite", filtered);
      console.log(`[Invite] ${clientId} توكن خاطئ وتم حذفه`);
    });
});
