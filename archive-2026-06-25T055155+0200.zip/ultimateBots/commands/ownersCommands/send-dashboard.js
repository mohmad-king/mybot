const {
    ChatInputCommandInteraction,
    Client,
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");
const { Database } = require("st.db");
const setting     = new Database("database/settingsdata/setting");
const customTexts = new Database("database/settingsdata/custom_panels");
const { mainguild } = require('../../../config.json');

const DEFAULT_DASHBOARD_TEXT = `- **Redeem**\n> يمكنك استخدام أكواد الخصم لاستلام المكافآت الخاصة بالكود.\n- **My Bots**\n> يمكنك مشاهدة جميع معلومات البوتات التي قمت بشرائها والتحكم فيها، بما في ذلك تجديد الاشتراك وتغيير معلومات البوت وغيرها.\n- **Report Problem**\n> يمكنك التبليغ عن أي مشكلة تواجهها في بوتات الميكر أو حتى الميكر نفسه.\n- **Suggestion**\n> يمكنك اقتراح أفكارك حول بوتات الميكر أو حتى الميكر نفسه. إذا أعجبنا اقتراحك، سنقوم بتنفيذه ومنحك مكافأة قيمة.\n\`\`\`\nأي استهتار يعرضك للإدراج في القائمة السوداء من خدمات الميكر\n\`\`\``;

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('send-dashboard')
        .setDescription('إرسال داشبورد لوحة تحكم الميكر'),

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const guildId = interaction.guild.id;

        const dashboardRoomId = await setting.get(`dashboard_room_${guildId}`);
        if (!dashboardRoomId) {
            return interaction.editReply({ content: '❌ **لم يتم تحديد روم الداشبورد.** استخدم `/setup` أولاً.' });
        }

        const dashboardRoom = interaction.guild.channels.cache.get(dashboardRoomId);
        if (!dashboardRoom) {
            return interaction.editReply({ content: `❌ **الروم غير موجود في السيرفر.** تأكد من صحة ID: \`${dashboardRoomId}\`` });
        }

        const botMember  = interaction.guild.members.me ?? interaction.guild.members.cache.get(client.user.id);
        const botColor   = botMember?.displayHexColor || '#2b2d31';
        const embedColor = guildId === mainguild ? '#00add9' : botColor;

        const customText    = await customTexts.get(`dashboard_text_${guildId}`);
        const dashboardText = customText ?? DEFAULT_DASHBOARD_TEXT;

        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTitle('🖥️ لوحة تحكم بوتات الميكر')
            .setDescription(dashboardText)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setColor(embedColor)
            .setTimestamp()
            .setFooter({ text: 'تم الإرسال بواسطة النظام الآلي' });

        const components = [
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('RedeemCodeModalShow').setLabel('🎁 Redeem').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('MyBots').setLabel('🤖 My Bots').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('CheckBalance').setLabel('💰 رصيدي').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('ReportProblem').setLabel('🚨 Report Problem').setStyle(ButtonStyle.Danger),
            ),
            new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('Suggestion').setLabel('💡 Suggestion').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('ViewInvoices').setLabel('🧾 فواتيري').setStyle(ButtonStyle.Secondary),
            ),
        ];

        try {
            await dashboardRoom.send({ embeds: [embed], components });
        } catch (err) {
            console.error('[send-dashboard] Error:', err);
            return interaction.editReply({ content: `❌ فشل إرسال الداشبورد: \`${err.message}\`` });
        }

        return interaction.editReply({ content: `✅ **تم إرسال الداشبورد بنجاح** في ${dashboardRoom}` });
    },
};
