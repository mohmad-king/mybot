const {
    ChatInputCommandInteraction,
    Client,
    SlashCommandBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");
const { Database } = require("st.db");
const setting     = new Database("database/settingsdata/setting");
const prices      = new Database("database/settingsdata/prices.json");
const customTexts = new Database("database/settingsdata/custom_panels");
const { mainguild } = require('../../../config.json');

const DEFAULT_BUY_PANEL_TEXT = `**1- Bots will be updated regularly to fix bugs and add new features, at no additional cost to users.\n\n2- We are committed to the confidentiality of customer information and will not sell or share data with third parties without prior customer consent.\n\n3- Users must adhere to the fair usage policy and refrain from overusing the service in a manner that impacts the performance of the bots or the service provided to others.\n\n4- No refunds will be issued after the purchase is complete, except in exceptional cases and after review by the technical support team.\n\n5- If you purchase a broadcast bot, we cannot compensate you for the bot's suspension.\n\n6- We are not responsible for failure to unlock your private information before purchasing any bot.**`;

function buildSubscribeText(guildId, pricesDb) {
    const p = (key, def) => pricesDb.get(`${key}_${guildId}`) ?? def;
    return `**## :bar_chart: باقات الاشتراك في خدمات البوتات :bar_chart:\n
### :gem: | البريميوم :\n- بيع البوتات العادية\n- بيع توكنات البوتات\n- تخصيص اسم و صورة لبوتك\n- تجديد البوتات تلقائيا\n- ~~بيع بوت واحد للكل~~\n- ~~بيع ميكرات~~\n- ___السعر___ : \`${p('bot_maker_premium_price', '350')}\` عملة شهريا\n\n### :fire: | التيميت :\n- بيع البوتات العادية\n- بيع توكنات البوتات\n- تخصيص اسم و صورة لبوتك\n- تجديد البوتات تلقائيا\n- بيع بوت واحد للكل\n- بيع ميكرات ( بريميوم / ~~التيميت~~ )\n- ___السعر___ : \`${p('bot_maker_ultimate_price', '500')}\` عملة شهريا\n\n### [+] التيميت بلس :\n- جميع مميزات باقة التيميت\n- بيع ميكرات التيميت\n- يجب شراء بوت ميكر التيميت أولاً\n- ___السعر___ : \`700\` عملة اسبوعيا**`;
}

function buildBuyComponents() {
    const select = new StringSelectMenuBuilder()
        .setCustomId('select_buy')
        .setPlaceholder('قم بالاختيار من القائمة')
        .addOptions(
            new StringSelectMenuOptionBuilder().setEmoji('🤖').setLabel('Buy bot').setDescription('شراء بوت شغال 24 ساعة').setValue('selectBuyBot'),
            new StringSelectMenuOptionBuilder().setEmoji('🔃').setLabel('Reset').setDescription('عمل اعادة تعيين للاختيار').setValue('Reset_Selected'),
        );
    const infoBtn    = new ButtonBuilder().setCustomId('buyBotInfo').setStyle(ButtonStyle.Secondary).setEmoji('<:translate:1363510431896830104>');
    const myBotsBtn  = new ButtonBuilder().setCustomId('MyBots').setLabel('My Bots').setStyle(ButtonStyle.Success);
    const balanceBtn = new ButtonBuilder().setCustomId('CheckBalance').setLabel('💰 رصيدي').setStyle(ButtonStyle.Primary);
    return [
        new ActionRowBuilder().addComponents(select),
        new ActionRowBuilder().addComponents(infoBtn, myBotsBtn, balanceBtn),
    ];
}

function buildSubscribeComponents() {
    const select = new StringSelectMenuBuilder()
        .setCustomId('select_bot')
        .setPlaceholder('الاشتراك في بوت الميكر')
        .addOptions(
                        new StringSelectMenuOptionBuilder().setEmoji('💎').setLabel('Premium').setDescription('الاشتراك في بوت الميكر بريميوم').setValue('Bot_Maker_Premium_Subscribe'),
            new StringSelectMenuOptionBuilder().setEmoji('🔥').setLabel('Ultimate').setDescription('الاشتراك في بوت الميكر التيميت').setValue('Bot_Maker_Ultimate_Subscribe'),
            new StringSelectMenuOptionBuilder().setEmoji('❇️').setLabel('Ultimate Plus').setDescription('الاشتراك في بوت الميكر التيميت بلس').setValue('Bot_Maker_Ultimate_Plus_Subscribe'),
            new StringSelectMenuOptionBuilder().setEmoji('🔃').setLabel('Reset').setDescription('عمل اعادة تعيين للاختيار').setValue('Reset_Selected'),
        );
    const infoBtn    = new ButtonBuilder().setCustomId('buyBotInfo').setStyle(ButtonStyle.Secondary).setEmoji('<:translate:1363510431896830104>');
    const myBotsBtn  = new ButtonBuilder().setCustomId('MyBots').setLabel('My Bots').setStyle(ButtonStyle.Success);
    const balanceBtn = new ButtonBuilder().setCustomId('CheckBalance').setLabel('💰 رصيدي').setStyle(ButtonStyle.Primary);
    return [
        new ActionRowBuilder().addComponents(select),
        new ActionRowBuilder().addComponents(infoBtn, myBotsBtn, balanceBtn),
    ];
}

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('send-buy-bot-panel')
        .setDescription('ارسال بانل شراء البوتات'),

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const guildId = interaction.guild.id;

        // ── Validate settings ──
        const [recipient, logroom, probot, clientrole, buybotroom] = await Promise.all([
            setting.get(`recipient_${guildId}`),
            setting.get(`log_room_${guildId}`),
            setting.get(`probot_${guildId}`),
            setting.get(`client_role_${guildId}`),
            setting.get(`buy_bot_room${guildId}`),
        ]);

        if (!buybotroom) {
            return interaction.editReply({ content: '❌ **لم يتم تحديد روم شراء البوتات.** استخدم `/setup buybotroom:#الروم` أولاً.' });
        }

        const buyRoom = interaction.guild.channels.cache.get(buybotroom);
        if (!buyRoom) {
            return interaction.editReply({ content: '❌ **تعذّر إيجاد روم شراء البوت. تأكد من صحة الإعدادات.**' });
        }

        // ── Bot member & color ──
        const botMember  = interaction.guild.members.me ?? interaction.guild.members.cache.get(client.user.id);
        const botColor   = botMember?.displayHexColor || '#2b2d31';
        const embedColor = guildId === mainguild ? '#f1c40f' : botColor;

        // ── Custom texts ──
        const [customBuyText, customSubText, customSubImage] = await Promise.all([
            customTexts.get(`buy_panel_text_${guildId}`),
            customTexts.get(`subscribe_text_${guildId}`),
            customTexts.get(`subscribe_image_${guildId}`),
        ]);

        const buyPanelText = customBuyText ?? DEFAULT_BUY_PANEL_TEXT;

        // ── Buy embed ──
        const buyEmbed = new EmbedBuilder()
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setDescription(buyPanelText)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setColor(embedColor)
            .setTimestamp()
            .setFooter({ text: 'تم الإرسال بواسطة النظام الآلي' });

        try {
            await buyRoom.send({ embeds: [buyEmbed], components: buildBuyComponents() });
        } catch (err) {
            console.error('[send-buy-bot-panel] Error sending buy panel:', err);
            return interaction.editReply({ content: `❌ فشل الإرسال في روم الشراء: \`${err.message}\`` });
        }

        // ── Subscribe panel (optional) ──
        const subscribeRoomId = await setting.get(`subscribe_room_${guildId}`);
        let subscribeSent = false;

        if (subscribeRoomId) {
            const subscribeRoom = interaction.guild.channels.cache.get(subscribeRoomId);
            if (!subscribeRoom) {
                return interaction.editReply({ content: '⚠️ بانل الشراء تم إرساله، لكن روم الاشتراكات غير موجود.' });
            }

            const subscribeText  = customSubText ?? buildSubscribeText(guildId, prices);
            const subEmbedColor  = guildId === mainguild ? '#00add9' : botColor;

            const subEmbed = new EmbedBuilder()
                .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setDescription(subscribeText)
                .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
                .setColor(subEmbedColor)
                .setTimestamp()
                .setFooter({ text: 'تم الإرسال بواسطة النظام الآلي' });

            if (guildId === mainguild) {
                subEmbed.setImage(customSubImage ?? 'https://i.postimg.cc/7PjkVgr7/6f543870a60e5035.webp');
            } else if (customSubImage) {
                subEmbed.setImage(customSubImage);
            }

            try {
                await subscribeRoom.send({ embeds: [subEmbed], components: buildSubscribeComponents() });
                subscribeSent = true;
            } catch (err) {
                console.error('[send-buy-bot-panel] Error sending subscribe panel:', err);
                return interaction.editReply({ content: `⚠️ بانل الشراء تم، لكن فشل إرسال بانل الاشتراكات: \`${err.message}\`` });
            }
        }

        const lines = [
            `✅ **تم إرسال بانل الشراء** في ${buyRoom}`,
            subscribeSent
                ? `✅ **تم إرسال بانل الاشتراكات** في <#${subscribeRoomId}>`
                : '⚠️ لم يتم العثور على روم الاشتراكات – تم إرسال بانل الشراء فقط.',
        ];
        return interaction.editReply({ content: lines.join('\n') });
    },
};
