const {
    ChatInputCommandInteraction,
    Client,
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");
const { Database } = require("st.db");
const setting = new Database("database/settingsdata/setting");
const prices = new Database("database/settingsdata/prices.json");
const { mainguild } = require('../../../config.json');
const { isOwner } = require('../../../utils/isOwner');

// مفاتيح حفظ النصوص والصور المخصصة
const customTexts = new Database("database/settingsdata/custom_panels");

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('edit-panel')
        .setDescription('تعديل نصوص وصور البانلات')
        .addStringOption(option =>
            option.setName('target')
                .setDescription('اختر البانل المراد تعديله')
                .setRequired(true)
                .addChoices(
                    { name: '📋 نص الداشبورد', value: 'dashboard_text' },
                    { name: '📜 نص بانل الاشتراكات', value: 'subscribe_text' },
                    { name: '🖼️ صورة بانل الاشتراكات', value: 'subscribe_image' },
                    { name: '🛒 نص بانل الشراء', value: 'buy_panel_text' },
                    { name: '🔄 إعادة تعيين (الافتراضي)', value: 'reset' },
                )
        )
        .addStringOption(option =>
            option.setName('value')
                .setDescription('النص الجديد أو رابط الصورة')
                .setRequired(false)
        ),

    async execute(interaction, client) {
        if (!isOwner(interaction.user.id, interaction.guild)) return;

        await interaction.deferReply({ ephemeral: true });

        const target = interaction.options.getString('target');
        const value = interaction.options.getString('value');
        const guildId = interaction.guild.id;

        const theBotMember = interaction.guild.members.cache.get(interaction.client.user.id);
        const botColor = theBotMember?.displayHexColor || '#00add9';
        const finalColor = guildId === mainguild ? '#00add9' : botColor;

        // ─── إعادة تعيين ───
        if (target === 'reset') {
            await customTexts.delete(`dashboard_text_${guildId}`);
            await customTexts.delete(`subscribe_text_${guildId}`);
            await customTexts.delete(`subscribe_image_${guildId}`);
            await customTexts.delete(`buy_panel_text_${guildId}`);

            const embed = new EmbedBuilder()
                .setTitle('✅ تم إعادة التعيين')
                .setDescription('تم حذف جميع التعديلات المخصصة وسيتم استخدام النصوص الافتراضية.')
                .setColor(finalColor)
                .setTimestamp();
            return interaction.editReply({ embeds: [embed] });
        }

        // ─── تحقق من القيمة ───
        if (!value) {
            const currentVal = await customTexts.get(`${target}_${guildId}`);
            const embed = new EmbedBuilder()
                .setTitle('📝 القيمة الحالية')
                .setDescription(
                    target === 'subscribe_image'
                        ? `**الصورة الحالية:**\n${currentVal ?? '*(افتراضية)*'}`
                        : `\`\`\`\n${(currentVal ?? '*(افتراضي)*').slice(0, 1800)}\n\`\`\``
                )
                .setColor(finalColor)
                .setFooter({ text: 'أضف القيمة الجديدة في خيار value' });

            if (target === 'subscribe_image' && currentVal) embed.setImage(currentVal);
            return interaction.editReply({ embeds: [embed] });
        }

        // ─── تحقق رابط الصورة ───
        if (target === 'subscribe_image') {
            const urlRegex = /^https?:\/\/.+\.(png|jpg|jpeg|gif|webp)(\?.*)?$/i;
            if (!urlRegex.test(value)) {
                return interaction.editReply({ content: '❌ الرابط غير صالح. يجب أن يكون رابط صورة مباشراً (png, jpg, gif, webp).' });
            }
        }

        // ─── حفظ القيمة ───
        await customTexts.set(`${target}_${guildId}`, value);

        const labels = {
            dashboard_text: 'نص الداشبورد',
            subscribe_text: 'نص بانل الاشتراكات',
            subscribe_image: 'صورة بانل الاشتراكات',
            buy_panel_text: 'نص بانل الشراء',
        };

        const embed = new EmbedBuilder()
            .setTitle(`✅ تم تحديث ${labels[target]}`)
            .setColor(finalColor)
            .setTimestamp()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

        if (target === 'subscribe_image') {
            embed.setDescription('تم تحديث الصورة. ستظهر في المرة القادمة عند إرسال بانل الاشتراكات.')
                 .setImage(value);
        } else {
            embed.setDescription(`**المعاينة:**\n${value.slice(0, 1024)}`);
        }

        return interaction.editReply({ embeds: [embed] });
    }
};
