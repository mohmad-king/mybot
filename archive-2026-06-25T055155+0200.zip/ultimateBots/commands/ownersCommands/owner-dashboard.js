const {
    ChatInputCommandInteraction,
    Client,
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    Events,
} = require("discord.js");
const { Database } = require("st.db");
const { isOwner } = require('../../../utils/isOwner');
const tokens      = new Database("tokens/tokens");
const usersdata   = new Database(`database/usersdata/usersdata`);
const setting     = new Database("database/settingsdata/setting");
const prices      = new Database("database/settingsdata/prices.json");
const ownerDashDB = new Database("Json-db/Others/ownerDashboard");
// Maker subscription databases — stored alongside existing makers DBs
const makerUltimate     = new Database("database/makers/tier3/makerUltimateSubs");
const makerUltimatePlus = new Database("database/makers/tier3/makerUltimatePlusSubs");
// اشتراكات Prime و Prime+ (يُباع بواسطة الميكرات)
const makerPrime        = new Database("database/makers/tier3/makerPrimeSubs");
const makerPrimePlus    = new Database("database/makers/tier3/makerPrimePlusSubs");

function getPlanDB(plan) {
    const dbs = { prime: makerPrime, primePlus: makerPrimePlus, ultimate: makerUltimate, ultimatePlus: makerUltimatePlus };
    return dbs[plan] || null;
}
function getPlanLabel(plan) {
    const labels = { prime: '🌟 Prime', primePlus: '💎 Prime+', ultimate: '🔥 Ultimate', ultimatePlus: '👑 Ultimate+' };
    return labels[plan] || plan;
}

// ──────────────────────────────────────────────────────────
//  Helper: check owner
// ──────────────────────────────────────────────────────────


// ──────────────────────────────────────────────────────────
//  Build the main control panel embed + buttons
// ──────────────────────────────────────────────────────────
function buildMainPanel(client) {
    const embed = new EmbedBuilder()
        .setTitle('🛠️ لوحة تحكم الأونر - الكاملة')
        .setDescription(
            '> تحكم كامل بالبوت الأساسي من هنا\n\n' +
            '**📋 الأقسام المتاحة:**\n' +
            '> 🤖 **إدارة البوتات** - عرض وإدارة جميع البوتات\n' +
            '> 💰 **إدارة الرصيد** - إضافة وسحب رصيد المستخدمين\n' +
            '> 📊 **إحصائيات** - عرض إحصائيات البوت\n' +
            '> ⚙️ **إعدادات البوت** - تغيير اسم وصورة البوت الرئيسي\n' +
            '> 🚫 **القائمة السوداء** - إدارة الحظر\n' +
            '> 📢 **الإعلانات** - إرسال رسائل لجميع الخوادم\\n' +
            '> 🎟️ **اشتراكات الميكرات** - إدارة اشتراكات التيميت والتيميت بلس\n' +
            '> 💲 **أسعار الاشتراكات** - تغيير سعر بريميوم / تيميت / تيميت بلس\n' +
            '> 🏷️ **أسعار البوتات الفرعية** - تغيير سعر أي بوت فرعي'
        )
        .setColor('#00add9')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: `لوحة تحكم الأونر | ${client.user.username}` })
        .setTimestamp();

    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('od_bots').setLabel('🤖 إدارة البوتات').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('od_balance').setLabel('💰 إدارة الرصيد').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('od_stats').setLabel('📊 الإحصائيات').setStyle(ButtonStyle.Secondary),
    );
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('od_botsettings').setLabel('⚙️ إعدادات البوت').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('od_broadcast').setLabel('📢 إعلان عام').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('od_prices').setLabel('💲 أسعار البوتات').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('od_botprices').setLabel('🏷️ أسعار البوتات الفرعية').setStyle(ButtonStyle.Primary),
    );
    const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('od_makersubs').setLabel('🎟️ اشتراكات الميكرات').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('od_subprices').setLabel('💲 أسعار الاشتراكات').setStyle(ButtonStyle.Primary),
    );

    return { embed, rows: [row1, row2, row3] };
}

// ──────────────────────────────────────────────────────────
//  Module Export (Slash Command)
// ──────────────────────────────────────────────────────────
module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('owner-dashboard')
        .setDescription('🛠️ لوحة تحكم الأونر الكاملة للبوت الأساسي'),

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        if (!isOwner(interaction.user.id, interaction.guild)) {
            return interaction.editReply({ content: '❌ هذا الأمر للأونر فقط!' });
        }

        const { embed, rows } = buildMainPanel(client);
        return interaction.editReply({ embeds: [embed], components: rows });
    },
};

// ──────────────────────────────────────────────────────────
//  Button / Modal Handler  (exported as a separate event)
//  We piggyback on interactionCreate via the buttons folder
// ──────────────────────────────────────────────────────────
module.exports.buttonHandler = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        const { client } = interaction;

        // ─── Guard ───────────────────────────────────────
        if (!interaction.isButton() && !interaction.isModalSubmit() && !interaction.isStringSelectMenu()) return;
        const id = interaction.customId;
        if (!id.startsWith('od_') && !id.startsWith('ownerDash_')) return;
        if (!isOwner(interaction.user.id, interaction.guild)) {
            return interaction.reply({ content: '❌ هذا الأمر للأونر فقط!', ephemeral: true });
        }

        // ═══════════════════════════════════════════════════
        //  🤖  إدارة البوتات
        // ═══════════════════════════════════════════════════
        if (id === 'od_bots') {
            await interaction.deferReply({ ephemeral: true });

            // Count all bot types
            const botTypes = [
                "azkar","shopRooms","scam","Bc","tax","logs","ticket","blacklist",
                "probot","autoline","feedback","suggestions","giveaway","apply",
                "nadeko","Broadcast2","protect","system","shop","orders",
                "privateRooms","roles","quran","one4all","games","offers","offer","auction","store","lnvite","ai"
            ];

            let totalBots = 0;
            const typeCounts = [];
            for (const t of botTypes) {
                const arr = tokens.get(t) || [];
                if (arr.length > 0) {
                    totalBots += arr.length;
                    typeCounts.push(`> **${t}**: \`${arr.length}\` بوت`);
                }
            }

            const embed = new EmbedBuilder()
                .setTitle('🤖 إدارة البوتات')
                .setDescription(
                    `**📦 إجمالي البوتات المسجلة: \`${totalBots}\`**\n\n` +
                    (typeCounts.length > 0 ? typeCounts.slice(0, 20).join('\n') : '> لا توجد بوتات مسجلة')
                )
                .setColor('#5865F2')
                .setTimestamp();

            const rows = [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('od_bot_mainsettings').setLabel('⚙️ إعدادات البوت الرئيسي').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('od_bot_listall').setLabel('📋 قائمة كل البوتات').setStyle(ButtonStyle.Secondary),
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
                )
            ];
            return interaction.editReply({ embeds: [embed], components: rows });
        }

        // ═══════════════════════════════════════════════════
        //  💰  إدارة الرصيد
        // ═══════════════════════════════════════════════════
        if (id === 'od_balance') {
            const modal = new ModalBuilder().setCustomId('ownerDash_balanceModal').setTitle('💰 إدارة رصيد المستخدم');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('bal_userId').setLabel('ايدي المستخدم').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('bal_amount').setLabel('المبلغ (رقم موجب للإضافة، سالب للخصم)').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('bal_guildId').setLabel('ايدي السيرفر').setStyle(TextInputStyle.Short).setRequired(true)
                ),
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_balanceModal') {
            await interaction.deferReply({ ephemeral: true });
            const userId  = interaction.fields.getTextInputValue('bal_userId').trim();
            const amount  = parseInt(interaction.fields.getTextInputValue('bal_amount').trim());
            const guildId = interaction.fields.getTextInputValue('bal_guildId').trim();

            if (isNaN(amount)) return interaction.editReply({ content: '❌ أدخل رقماً صحيحاً للمبلغ!' });

            const key = `balance_${userId}_${guildId}`;
            const currentBal = usersdata.get(key) ?? 0;
            const newBal = Math.max(0, currentBal + amount);
            usersdata.set(key, newBal);

            const action = amount >= 0 ? `✅ تم إضافة \`${amount}\` للمستخدم` : `✅ تم خصم \`${Math.abs(amount)}\` من المستخدم`;
            const embed = new EmbedBuilder()
                .setDescription(`${action} <@${userId}>\n> الرصيد القديم: \`${currentBal}\` 🪙\n> الرصيد الجديد: \`${newBal}\` 🪙`)
                .setColor(amount >= 0 ? 'Green' : 'Red')
                .setTimestamp();
            return interaction.editReply({ embeds: [embed] });
        }

        // ═══════════════════════════════════════════════════
        //  📊  الإحصائيات
        // ═══════════════════════════════════════════════════
        if (id === 'od_stats') {
            await interaction.deferReply({ ephemeral: true });

            const botTypes = [
                "azkar","shopRooms","scam","Bc","tax","logs","ticket","blacklist",
                "probot","autoline","feedback","suggestions","giveaway","apply",
                "nadeko","Broadcast2","protect","system","shop","orders",
                "privateRooms","roles","quran","one4all","games","offers","offer","auction","store","lnvite","ai"
            ];
            let totalBots = 0;
            for (const t of botTypes) {
                const arr = tokens.get(t) || [];
                totalBots += arr.length;
            }

            const guildsCount = client.guilds.cache.size;
            const usersCount  = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
            const uptime = process.uptime();
            const uptimeStr = `${Math.floor(uptime/3600)}h ${Math.floor((uptime%3600)/60)}m ${Math.floor(uptime%60)}s`;

            const embed = new EmbedBuilder()
                .setTitle('📊 إحصائيات البوت الرئيسي')
                .addFields(
                    { name: '🏠 عدد السيرفرات', value: `\`${guildsCount}\``, inline: true },
                    { name: '👥 عدد المستخدمين', value: `\`${usersCount}\``, inline: true },
                    { name: '🤖 البوتات المسجلة', value: `\`${totalBots}\``, inline: true },
                    { name: '⏱️ مدة التشغيل', value: `\`${uptimeStr}\``, inline: true },
                    { name: '💾 الذاكرة', value: `\`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\``, inline: true },
                    { name: '🏷️ اسم البوت', value: `\`${client.user.username}\``, inline: true },
                )
                .setColor('#FFD700')
                .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
            );
            return interaction.editReply({ embeds: [embed], components: [row] });
        }

        // ═══════════════════════════════════════════════════
        //  ⚙️  إعدادات البوت الرئيسي
        // ═══════════════════════════════════════════════════
        if (id === 'od_botsettings' || id === 'od_bot_mainsettings') {
            const embed = new EmbedBuilder()
                .setTitle('⚙️ إعدادات البوت الرئيسي')
                .setDescription('> اختر ما تريد تعديله في البوت الرئيسي')
                .setColor('#5865F2')
                .setThumbnail(client.user.displayAvatarURL({ dynamic: true }));

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('od_changeUsername').setLabel('📝 تغيير الاسم').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('od_changeAvatar').setLabel('🖼️ تغيير الصورة').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('od_changeStatus').setLabel('💬 تغيير الحالة').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
            );
            return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
        }

        if (id === 'od_changeUsername') {
            const modal = new ModalBuilder().setCustomId('ownerDash_changeUsernameModal').setTitle('📝 تغيير اسم البوت الرئيسي');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('new_username').setLabel('الاسم الجديد').setStyle(TextInputStyle.Short).setMinLength(2).setMaxLength(32).setRequired(true)
                )
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_changeUsernameModal') {
            await interaction.deferReply({ ephemeral: true });
            const newName = interaction.fields.getTextInputValue('new_username').trim();
            try {
                await client.user.setUsername(newName);
                return interaction.editReply({ content: `✅ تم تغيير اسم البوت إلى \`${newName}\` بنجاح!` });
            } catch (e) {
                return interaction.editReply({ content: `❌ فشل تغيير الاسم: \`${e.message}\`` });
            }
        }

        if (id === 'od_changeAvatar') {
            const modal = new ModalBuilder().setCustomId('ownerDash_changeAvatarModal').setTitle('🖼️ تغيير صورة البوت الرئيسي');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('new_avatar').setLabel('رابط الصورة الجديدة').setStyle(TextInputStyle.Short).setRequired(true)
                )
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_changeAvatarModal') {
            await interaction.deferReply({ ephemeral: true });
            const avatarUrl = interaction.fields.getTextInputValue('new_avatar').trim();
            try {
                await client.user.setAvatar(avatarUrl);
                return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(`✅ **تم تغيير صورة البوت بنجاح!**`).setImage(avatarUrl).setColor('Green')] });
            } catch (e) {
                return interaction.editReply({ content: `❌ فشل تغيير الصورة: \`${e.message}\`` });
            }
        }

        if (id === 'od_changeStatus') {
            const modal = new ModalBuilder().setCustomId('ownerDash_changeStatusModal').setTitle('💬 تغيير حالة البوت');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('status_text').setLabel('نص الحالة').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('status_type').setLabel('النوع: playing/watching/listening').setStyle(TextInputStyle.Short).setRequired(true).setValue('playing')
                ),
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_changeStatusModal') {
            await interaction.deferReply({ ephemeral: true });
            const statusText = interaction.fields.getTextInputValue('status_text').trim();
            const statusType = interaction.fields.getTextInputValue('status_type').trim().toLowerCase();

            const validTypes = ['playing', 'watching', 'listening', 'competing'];
            if (!validTypes.includes(statusType)) {
                return interaction.editReply({ content: `❌ النوع غير صحيح! استخدم: ${validTypes.join(', ')}` });
            }

            try {
                client.user.setPresence({
                    activities: [{ name: statusText, type: { playing: 0, listening: 2, watching: 3, competing: 5 }[statusType] }],
                    status: 'online',
                });
                return interaction.editReply({ content: `✅ تم تغيير حالة البوت إلى: **${statusType}** \`${statusText}\`` });
            } catch (e) {
                return interaction.editReply({ content: `❌ فشل تغيير الحالة: \`${e.message}\`` });
            }
        }

        // ═══════════════════════════════════════════════════
        //  📢  إعلان عام لجميع السيرفرات
        // ═══════════════════════════════════════════════════
        if (id === 'od_broadcast') {
            const modal = new ModalBuilder().setCustomId('ownerDash_broadcastModal').setTitle('📢 إعلان عام');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('broadcast_title').setLabel('عنوان الإعلان').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('broadcast_msg').setLabel('نص الإعلان').setStyle(TextInputStyle.Paragraph).setRequired(true)
                ),
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_broadcastModal') {
            await interaction.deferReply({ ephemeral: true });
            const title   = interaction.fields.getTextInputValue('broadcast_title').trim();
            const message = interaction.fields.getTextInputValue('broadcast_msg').trim();

            const embed = new EmbedBuilder()
                .setTitle(`📢 ${title}`)
                .setDescription(message)
                .setColor('#00add9')
                .setFooter({ text: `إعلان من الإدارة | ${client.user.username}` })
                .setTimestamp();

            let sentCount = 0;
            let failCount = 0;
            const guilds = [...client.guilds.cache.values()];

            for (const guild of guilds) {
                try {
                    // Try to find a suitable channel
                    const channels = guild.channels.cache
                        .filter(ch => ch.isTextBased() && !ch.isThread() && ch.permissionsFor(guild.members.me)?.has(['SendMessages', 'EmbedLinks']))
                        .sort((a, b) => a.position - b.position);

                    const target = channels.first();
                    if (target) {
                        await target.send({ embeds: [embed] });
                        sentCount++;
                    }
                } catch (_) {
                    failCount++;
                }
            }

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(`✅ تم إرسال الإعلان إلى \`${sentCount}\` سيرفر\n❌ فشل في \`${failCount}\` سيرفر`)
                    .setColor('Green').setTimestamp()]
            });
        }

        // ═══════════════════════════════════════════════════
        //  💲  إدارة الأسعار
        // ═══════════════════════════════════════════════════
        if (id === 'od_prices') {
            const modal = new ModalBuilder().setCustomId('ownerDash_priceModal').setTitle('💲 تغيير سعر نوع بوت');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('price_type').setLabel('نوع البوت (مثال: ticket, system, roles)').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('price_buy').setLabel('سعر الشراء الجديد').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('price_renew').setLabel('سعر التجديد اليومي (كوين/يوم)').setStyle(TextInputStyle.Short).setRequired(true)
                ),
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_priceModal') {
            await interaction.deferReply({ ephemeral: true });
            const botType   = interaction.fields.getTextInputValue('price_type').trim();
            const buyPrice  = parseInt(interaction.fields.getTextInputValue('price_buy').trim());
            const renewPrice = parseInt(interaction.fields.getTextInputValue('price_renew').trim());

            if (isNaN(buyPrice) || isNaN(renewPrice)) {
                return interaction.editReply({ content: '❌ أدخل أرقاماً صحيحة!' });
            }

            prices.set(`buy_${botType}`, buyPrice);
            prices.set(`renew_${botType}`, renewPrice);

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(`✅ تم تحديث أسعار بوت **${botType}**\n> سعر الشراء: \`${buyPrice}\` 🪙\n> سعر التجديد: \`${renewPrice}\` كوين/يوم`)
                    .setColor('Green').setTimestamp()]
            });
        }

        // ═══════════════════════════════════════════════════
        //  📋  قائمة كل البوتات
        // ═══════════════════════════════════════════════════
        if (id === 'od_bot_listall') {
            await interaction.deferReply({ ephemeral: true });

            const botTypes = [
                "azkar","shopRooms","scam","Bc","tax","logs","ticket","blacklist",
                "probot","autoline","feedback","suggestions","giveaway","apply",
                "nadeko","Broadcast2","protect","system","shop","orders",
                "privateRooms","roles","quran","one4all","games","offers","offer","auction","store","lnvite","ai"
            ];

            // ✅ FIX: Max 25 fields per embed
            const fields = [];
            for (const t of botTypes) {
                const arr = tokens.get(t) || [];
                if (arr.length > 0) {
                    fields.push({ name: `🤖 ${t}`, value: `\`${arr.length}\` بوت مسجل`, inline: true });
                }
            }

            const embeds = [];
            for (let i = 0; i < fields.length; i += 25) {
                const chunk = fields.slice(i, i + 25);
                embeds.push(
                    new EmbedBuilder()
                        .setTitle(i === 0 ? '📋 جميع أنواع البوتات المسجلة' : '📋 تابع...')
                        .addFields(chunk)
                        .setColor('#5865F2')
                        .setTimestamp()
                );
            }

            if (embeds.length === 0) {
                return interaction.editReply({ content: '> لا توجد بوتات مسجلة حالياً.' });
            }

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
            );
            return interaction.editReply({ embeds: embeds.slice(0, 10), components: [row] });
        }

        // ═══════════════════════════════════════════════════
        //  🎟️  اشتراكات الميكرات (تيميت / تيميت بلس)
        // ═══════════════════════════════════════════════════
        if (id === 'od_makersubs') {
            // Show current maker subs overview
            const ultimateSubs     = makerUltimate.get('subs') || [];
            const ultimatePlusSubs = makerUltimatePlus.get('subs') || [];
            const primeSubs        = makerPrime.get('subs') || [];
            const primePlusSubs    = makerPrimePlus.get('subs') || [];

            const embed = new EmbedBuilder()
                .setTitle('🎟️ اشتراكات الميكرات')
                .setDescription(
                    `**👑 Ultimate+:** \`${ultimatePlusSubs.length}\` مشترك\n` +
                    `**🔥 Ultimate:** \`${ultimateSubs.length}\` مشترك\n` +
                    `**💎 Prime+:** \`${primePlusSubs.length}\` مشترك\n` +
                    `**🌟 Prime:** \`${primeSubs.length}\` مشترك\n\n` +
                    `> **الصلاحيات:**\n` +
                    `> Ultimate+ → يبيع Prime, Prime+, Ultimate\n` +
                    `> Ultimate  → يبيع Prime, Prime+`
                )
                .setColor('#FF6B35')
                .setTimestamp();

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('od_makersubs_add').setLabel('➕ إضافة مشترك').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('od_makersubs_remove').setLabel('➖ إزالة مشترك').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('od_makersubs_list').setLabel('📋 قائمة المشتركين').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
            );
            return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
        }

        if (id === 'od_makersubs_add') {
            const modal = new ModalBuilder().setCustomId('ownerDash_makerSubAddModal').setTitle('➕ إضافة اشتراك ميكر');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('maker_userId').setLabel('ايدي المستخدم').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('maker_type').setLabel('النوع: prime/premium/ultimate').setStyle(TextInputStyle.Short).setRequired(true).setValue('ultimate')
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('maker_slots').setLabel('عدد السلوتات (للـ ultimate/ultimatePlus فقط)').setStyle(TextInputStyle.Short).setRequired(false).setValue('0')
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('maker_days').setLabel('مدة الاشتراك بالأيام').setStyle(TextInputStyle.Short).setRequired(true)
                ),
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_makerSubAddModal') {
            await interaction.deferReply({ ephemeral: true });
            const userId = interaction.fields.getTextInputValue('maker_userId').trim();
            const type   = interaction.fields.getTextInputValue('maker_type').trim().toLowerCase();
            const slots  = parseInt(interaction.fields.getTextInputValue('maker_slots').trim()) || 0;
            const days   = parseInt(interaction.fields.getTextInputValue('maker_days').trim());

            const validTypes = ['prime', 'primeplus', 'ultimate', 'ultimateplus'];
            if (!validTypes.includes(type)) {
                return interaction.editReply({ content: '❌ النوع غير صحيح! استخدم: prime, primePlus, ultimate, ultimatePlus' });
            }
            if (isNaN(days) || days <= 0) {
                return interaction.editReply({ content: '❌ أدخل أرقاماً صحيحة للأيام!' });
            }

            // نطبّع الاسم ليطابق مفاتيح القاعدة
            const normalizedType = type === 'primeplus' ? 'primePlus' : type === 'ultimateplus' ? 'ultimatePlus' : type;
            const db = getPlanDB(normalizedType);
            if (!db) return interaction.editReply({ content: '❌ خطأ في النوع!' });

            const dbKey = 'subs';
            const subs = db.get(dbKey) || [];
            const existingIdx = subs.findIndex(s => s.userId === userId);
            const expireTime = Math.floor(Date.now() / 1000) + (days * 86400);

            if (existingIdx >= 0) {
                if (slots > 0) subs[existingIdx].slots = (subs[existingIdx].slots || 0) + slots;
                subs[existingIdx].usedSlots = subs[existingIdx].usedSlots || 0;
                subs[existingIdx].expireAt = expireTime;
            } else {
                const entry = { userId, type: normalizedType, expireAt: expireTime };
                if (['ultimate', 'ultimatePlus'].includes(normalizedType)) {
                    entry.slots = slots > 0 ? slots : 3;
                    entry.usedSlots = 0;
                }
                subs.push(entry);
            }
            db.set(dbKey, subs);

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(`✅ تم إضافة اشتراك **${getPlanLabel(normalizedType)}** لـ <@${userId}>\n> ${slots > 0 ? `السلوتات: \`${slots}\`\n> ` : ''}ينتهي: <t:${expireTime}:R>`)
                    .setColor('Green').setTimestamp()]
            });
        }

        if (id === 'od_makersubs_remove') {
            const modal = new ModalBuilder().setCustomId('ownerDash_makerSubRemoveModal').setTitle('➖ إزالة اشتراك ميكر');
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('maker_userId').setLabel('ايدي المستخدم').setStyle(TextInputStyle.Short).setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('maker_type').setLabel('النوع: prime/premium/ultimate').setStyle(TextInputStyle.Short).setRequired(true).setValue('ultimate')
                ),
            );
            return interaction.showModal(modal);
        }

        if (id === 'ownerDash_makerSubRemoveModal') {
            await interaction.deferReply({ ephemeral: true });
            const userId = interaction.fields.getTextInputValue('maker_userId').trim();
            const type   = interaction.fields.getTextInputValue('maker_type').trim().toLowerCase();
            const normalizedType = type === 'primeplus' ? 'primePlus' : type === 'ultimateplus' ? 'ultimatePlus' : type;
            const db = getPlanDB(normalizedType);
            if (!db) return interaction.editReply({ content: '❌ النوع غير صحيح!' });
            const subs = db.get('subs') || [];
            const newSubs = subs.filter(s => s.userId !== userId);
            if (newSubs.length === subs.length) {
                return interaction.editReply({ content: `❌ لم يتم إيجاد اشتراك للمستخدم \`${userId}\` في **${getPlanLabel(normalizedType)}**` });
            }
            db.set('subs', newSubs);
            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(`✅ تم إزالة اشتراك **${getPlanLabel(normalizedType)}** من <@${userId}>`)
                    .setColor('Red').setTimestamp()]
            });
        }

        if (id === 'od_makersubs_list') {
            await interaction.deferReply({ ephemeral: true });
            const ultimatePlusSubs = makerUltimatePlus.get('subs') || [];
            const ultimateSubs     = makerUltimate.get('subs') || [];
            const primePlusSubs    = makerPrimePlus.get('subs') || [];
            const primeSubs        = makerPrime.get('subs') || [];

            const now = Math.floor(Date.now() / 1000);
            const formatList = (arr, label) => {
                if (arr.length === 0) return `**${label}:** لا يوجد مشتركين\n`;
                return `**${label}:**\n` + arr.map(s => {
                    const slotInfo = s.slots ? ` | سلوت: \`${s.slots - (s.usedSlots||0)}/${s.slots}\`` : '';
                    return `> <@${s.userId}>${slotInfo} | ${s.expireAt > now ? `<t:${s.expireAt}:R>` : '❌ منتهي'}`;
                }).join('\n') + '\n';
            };

            const embed = new EmbedBuilder()
                .setTitle('📋 قائمة مشتركي الميكر')
                .setDescription(
                    formatList(ultimatePlusSubs, '👑 Ultimate+') + '\n' +
                    formatList(ultimateSubs, '🔥 Ultimate') + '\n' +
                    formatList(primePlusSubs, '💎 Prime+') + '\n' +
                    formatList(primeSubs, '🌟 Prime')
                )
                .setColor('#FF6B35')
                .setTimestamp();

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('od_makersubs').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
            );
            return interaction.editReply({ embeds: [embed], components: [row] });
        }


        // ═══════════════════════════════════════════════════
        //  🏷️  أسعار البوتات الفرعية
        // ═══════════════════════════════════════════════════
        if (id === 'od_botprices') {
            const guildId = interaction.guild.id;

            // البوتات مقسمة لمجموعات عشان Discord limit 25 خيار
            const GROUP1 = [
                { label: 'Ticket',    emoji: '🎫', key: 'ticket_price',    def: 160 },
                { label: 'Logs',      emoji: '📋', key: 'logs_price',      def: 40  },
                { label: 'Broadcast', emoji: '📢', key: 'Broadcast_price', def: 100 },
                { label: 'System',    emoji: '⚙️', key: 'system_price',    def: 100 },
                { label: 'Token',     emoji: '🔑', key: 'token_price',     def: 100 },
                { label: 'Roles',     emoji: '🎭', key: 'roles_price',     def: 70  },
                { label: 'Shop',      emoji: '🛒', key: 'shop_price',      def: 70  },
                { label: 'PrivateRooms', emoji: '🏠', key: 'privateRooms_price', def: 70 },
                { label: 'AI',        emoji: '🤖', key: 'ai_price',        def: 70  },
                { label: 'Tokenbot',  emoji: '🪙', key: 'tokenbot_price',  def: 60  },
                { label: 'Copy',      emoji: '📄', key: 'copy_price',      def: 90  },
                { label: 'Store',     emoji: '🏪', key: 'store_price',     def: 200 },
                { label: 'One4all',   emoji: '🌐', key: 'one4all_price',   def: 200 },
                { label: 'Giveaway',  emoji: '🎁', key: 'giveaway_price',  def: 40  },
                { label: 'Autoline',  emoji: '🔄', key: 'autoline_price',  def: 40  },
                { label: 'Feedback',  emoji: '💬', key: 'feedback_price',  def: 40  },
                { label: 'Probot',    emoji: '🛡️', key: 'probot_price',    def: 40  },
                { label: 'Protect',   emoji: '🔒', key: 'protect_price',   def: 40  },
                { label: 'Blacklist', emoji: '🚫', key: 'blacklist_price', def: 40  },
                { label: 'Scammers',  emoji: '⚠️', key: 'Scammers_price', def: 40  },
                { label: 'Suggestions', emoji: '💡', key: 'suggestions_price', def: 40 },
                { label: 'Apply',     emoji: '📝', key: 'apply_price',     def: 40  },
                { label: 'Orders',    emoji: '📦', key: 'orders_price',    def: 40  },
                { label: 'Invite',    emoji: '✉️', key: 'Invite_price',   def: 40  },
                { label: 'Tax',       emoji: '💸', key: 'tax_price',       def: 40  },
            ];
            const GROUP2 = [
                { label: 'NormalBroadcast', emoji: '📣', key: 'normalBroadcast_price', def: 40 },
                { label: 'ShopRooms', emoji: '🛍️', key: 'shopRooms_price', def: 40  },
                { label: 'Nadeko',    emoji: '🎵', key: 'nadeko_price',    def: 40  },
                { label: 'Auction',   emoji: '🔨', key: 'auction_price',   def: 40  },
                { label: 'Offer',     emoji: '🏷️', key: 'offer_price',    def: 20  },
                { label: 'Ticketbil', emoji: '🎟️', key: 'ticketbil_price', def: 40 },
                { label: 'Mongo',     emoji: '🗄️', key: 'mongo_price',    def: 40  },
                { label: 'Games',     emoji: '🎮', key: 'games_price',     def: 1   },
                { label: 'Download',  emoji: '⬇️', key: 'down_price',     def: 50  },
                { label: 'Quran',     emoji: '📖', key: 'quran_price',     def: 1   },
                { label: 'Azkar',     emoji: '🕌', key: 'azkar_price',     def: 1   },
                { label: 'Come',      emoji: '👋', key: 'come_price',      def: 15  },
                { label: 'Self',      emoji: '👤', key: 'self_price',      def: 15  },
                { label: 'Seller',    emoji: '💼', key: 'seller_price',    def: 15  },
                { label: 'Tools',     emoji: '🔧', key: 'tools_price',     def: 15  },
                { label: 'Code',      emoji: '💻', key: 'code_price',      def: 15  },
                { label: 'Credit',    emoji: '💳', key: 'credit_price',    def: 40  },
            ];

            const makeOptions = (group) => group.map(b => {
                const cur = prices.get(`${b.key}_${guildId}`) ?? b.def;
                return new StringSelectMenuOptionBuilder()
                    .setLabel(b.label)
                    .setDescription(`السعر الحالي: ${cur} عملة`)
                    .setValue(b.key)
                    .setEmoji(b.emoji);
            });

            const select1 = new StringSelectMenuBuilder()
                .setCustomId('od_botprice_select')
                .setPlaceholder('المجموعة الأولى — اختر بوتاً')
                .addOptions(makeOptions(GROUP1));

            const select2 = new StringSelectMenuBuilder()
                .setCustomId('od_botprice_select')
                .setPlaceholder('المجموعة الثانية — اختر بوتاً')
                .addOptions(makeOptions(GROUP2));

            const embed = new EmbedBuilder()
                .setTitle('🏷️ أسعار البوتات الفرعية')
                .setDescription('اختر البوت من القائمة لتعديل سعره')
                .setColor('#5865F2')
                .setTimestamp();

            return interaction.reply({
                embeds: [embed],
                components: [
                    new ActionRowBuilder().addComponents(select1),
                    new ActionRowBuilder().addComponents(select2),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
                    ),
                ],
                ephemeral: true,
            });
        }

        if (id === 'od_botprice_select') {
            const priceKey = interaction.values[0];
            const guildId  = interaction.guild.id;
            const curPrice = prices.get(`${priceKey}_${guildId}`) ?? '—';
            const botLabel = priceKey.replace('_price', '');

            const modal = new ModalBuilder()
                .setCustomId(`ownerDash_botprice_${priceKey}`)
                .setTitle(`🏷️ تغيير سعر ${botLabel}`);
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('new_price')
                        .setLabel(`السعر الجديد (الحالي: ${curPrice} عملة)`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                        .setMinLength(1)
                        .setMaxLength(10)
                )
            );
            return interaction.showModal(modal);
        }

        if (id.startsWith('ownerDash_botprice_')) {
            await interaction.deferReply({ ephemeral: true });
            const priceKey = id.replace('ownerDash_botprice_', '');
            const guildId  = interaction.guild.id;
            const newPrice = parseInt(interaction.fields.getTextInputValue('new_price').trim());

            if (isNaN(newPrice) || newPrice < 0) {
                return interaction.editReply({ content: '❌ أدخل رقماً صحيحاً!' });
            }

            prices.set(`${priceKey}_${guildId}`, newPrice);
            const botLabel = priceKey.replace('_price', '');

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(`✅ تم تحديث سعر بوت **${botLabel}** إلى \`${newPrice}\` عملة`)
                    .setColor('Green')
                    .setTimestamp()]
            });
        }


        // ═══════════════════════════════════════════════════
        //  💲  أسعار اشتراكات الميكرات (بريميوم / تيميت / تيميت بلس)
        // ═══════════════════════════════════════════════════
        if (id === 'od_subprices') {
            const premiumPrice      = prices.get(`bot_maker_premium_price_${interaction.guild.id}`)  ?? 350;
            const ultimatePrice     = prices.get(`bot_maker_ultimate_price_${interaction.guild.id}`) ?? 500;
            const ultimatePlusPrice = prices.get(`bot_maker_ultimate_plus_price_${interaction.guild.id}`) ?? 700;

            const embed = new EmbedBuilder()
                .setTitle('💲 أسعار اشتراكات الميكرات')
                .setDescription(
                    `**💎 بريميوم:** \`${premiumPrice}\` عملة/شهر\n` +
                    `**🔥 التيميت:** \`${ultimatePrice}\` عملة/شهر\n` +
                    `**👑 التيميت بلس:** \`${ultimatePlusPrice}\` عملة/أسبوع\n\n` +
                    `> اختر نوع الاشتراك لتعديل سعره`
                )
                .setColor('#00add9')
                .setTimestamp();

            const select = new StringSelectMenuBuilder()
                .setCustomId('od_subprices_select')
                .setPlaceholder('اختر نوع الاشتراك لتغيير سعره')
                .addOptions(
                    new StringSelectMenuOptionBuilder().setEmoji('💎').setLabel('بريميوم').setDescription(`السعر الحالي: ${premiumPrice} عملة/شهر`).setValue('premium'),
                    new StringSelectMenuOptionBuilder().setEmoji('🔥').setLabel('التيميت').setDescription(`السعر الحالي: ${ultimatePrice} عملة/شهر`).setValue('ultimate'),
                    new StringSelectMenuOptionBuilder().setEmoji('👑').setLabel('التيميت بلس').setDescription(`السعر الحالي: ${ultimatePlusPrice} عملة/أسبوع`).setValue('ultimateplus'),
                );

            const rows = [
                new ActionRowBuilder().addComponents(select),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('od_main').setLabel('🔙 رجوع').setStyle(ButtonStyle.Secondary),
                ),
            ];
            return interaction.reply({ embeds: [embed], components: rows, ephemeral: true });
        }

        if (id === 'od_subprices_select') {
            const selected = interaction.values[0];
            const labels = { premium: '💎 بريميوم', ultimate: '🔥 التيميت', ultimateplus: '👑 التيميت بلس' };
            const keys   = { premium: 'bot_maker_premium_price', ultimate: 'bot_maker_ultimate_price', ultimateplus: 'bot_maker_ultimate_plus_price' };

            const modal = new ModalBuilder()
                .setCustomId(`ownerDash_subprice_${selected}`)
                .setTitle(`💲 تغيير سعر ${labels[selected]}`);
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('new_price')
                        .setLabel('السعر الجديد (بالعملات)')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                        .setMinLength(1)
                        .setMaxLength(10)
                )
            );
            return interaction.showModal(modal);
        }

        if (id.startsWith('ownerDash_subprice_')) {
            await interaction.deferReply({ ephemeral: true });
            const plan = id.replace('ownerDash_subprice_', '');
            const labels = { premium: '💎 بريميوم', ultimate: '🔥 التيميت', ultimateplus: '👑 التيميت بلس' };
            const keys   = { premium: 'bot_maker_premium_price', ultimate: 'bot_maker_ultimate_price', ultimateplus: 'bot_maker_ultimate_plus_price' };

            if (!keys[plan]) return interaction.editReply({ content: '❌ نوع غير صحيح!' });

            const newPrice = parseInt(interaction.fields.getTextInputValue('new_price').trim());
            if (isNaN(newPrice) || newPrice <= 0) {
                return interaction.editReply({ content: '❌ أدخل رقماً صحيحاً أكبر من صفر!' });
            }

            prices.set(`${keys[plan]}_${interaction.guild.id}`, newPrice);

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(`✅ تم تحديث سعر **${labels[plan]}** إلى \`${newPrice}\` عملة`)
                    .setColor('Green')
                    .setTimestamp()]
            });
        }

        // ═══════════════════════════════════════════════════
        //  🔙  رجوع للقائمة الرئيسية
        // ═══════════════════════════════════════════════════
        if (id === 'od_main') {
            const { embed, rows } = buildMainPanel(client);
            return interaction.update({ embeds: [embed], components: rows });
        }
    }
};
