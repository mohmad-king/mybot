const {
    ChatInputCommandInteraction,
    Client,
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    Events,
} = require("discord.js");
const { Database } = require("st.db");
const { isOwner } = require('../../../utils/isOwner');
const prices = new Database("database/settingsdata/prices.json");

// isOwner is now imported from utils/isOwner

const PLANS = {
    premium:      { label: '💎 بريميوم',     key: 'bot_maker_premium_price',          period: 'شهر' },
    ultimate:     { label: '🔥 التيميت',      key: 'bot_maker_ultimate_price',         period: 'شهر' },
    ultimateplus: { label: '👑 التيميت بلس',  key: 'bot_maker_ultimate_plus_price',    period: 'أسبوع' },
};

function buildPricesEmbed(guildId) {
    const lines = Object.entries(PLANS).map(([, p]) => {
        const val = prices.get(`${p.key}_${guildId}`) ?? '—';
        return `**${p.label}:** \`${val}\` عملة/${p.period}`;
    }).join('\n');

    return new EmbedBuilder()
        .setTitle('💲 أسعار اشتراكات الميكر')
        .setDescription(lines + '\n\n> اختر نوع الاشتراك من القائمة لتعديل سعره')
        .setColor('#00add9')
        .setTimestamp();
}

function buildSelectMenu(guildId) {
    const options = Object.entries(PLANS).map(([val, p]) => {
        const cur = prices.get(`${p.key}_${guildId}`) ?? '—';
        return new StringSelectMenuOptionBuilder()
            .setLabel(p.label.replace(/^\S+\s/, ''))
            .setDescription(`السعر الحالي: ${cur} عملة/${p.period}`)
            .setValue(val)
            .setEmoji(p.label.split(' ')[0]);
    });

    return new StringSelectMenuBuilder()
        .setCustomId('dashprice_select')
        .setPlaceholder('اختر نوع الاشتراك')
        .addOptions(options);
}

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('dash-price')
        .setDescription('💲 تغيير أسعار اشتراكات الميكر (بريميوم / تيميت / تيميت بلس)'),

    async execute(interaction, client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        if (!isOwner(interaction.user.id, interaction.guild)) {
            return interaction.editReply({ content: '❌ هذا الأمر للأونر فقط!' });
        }

        const guildId = interaction.guild.id;
        const embed = buildPricesEmbed(guildId);
        const select = buildSelectMenu(guildId);

        return interaction.editReply({
            embeds: [embed],
            components: [new ActionRowBuilder().addComponents(select)],
        });
    },
};

module.exports.buttonHandler = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isStringSelectMenu() && !interaction.isModalSubmit()) return;
        const id = interaction.customId;
        if (!id.startsWith('dashprice_')) return;
        if (!isOwner(interaction.user.id, interaction.guild)) {
            return interaction.reply({ content: '❌ هذا الأمر للأونر فقط!', ephemeral: true });
        }

        // ── Select: اختيار النوع ──
        if (id === 'dashprice_select') {
            const plan = interaction.values[0];
            const p = PLANS[plan];
            if (!p) return interaction.reply({ content: '❌ نوع غير صحيح!', ephemeral: true });

            const curPrice = prices.get(`${p.key}_${interaction.guild.id}`) ?? '—';

            const modal = new ModalBuilder()
                .setCustomId(`dashprice_modal_${plan}`)
                .setTitle(`${p.label} — تغيير السعر`);
            modal.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('new_price')
                        .setLabel(`السعر الجديد (الحالي: ${curPrice} عملة/${p.period})`)
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true)
                        .setMinLength(1)
                        .setMaxLength(10)
                )
            );
            return interaction.showModal(modal);
        }

        // ── Modal Submit ──
        if (id.startsWith('dashprice_modal_')) {
            await interaction.deferReply({ ephemeral: true });
            const plan = id.replace('dashprice_modal_', '');
            const p = PLANS[plan];
            if (!p) return interaction.editReply({ content: '❌ نوع غير صحيح!' });

            const newPrice = parseInt(interaction.fields.getTextInputValue('new_price').trim());
            if (isNaN(newPrice) || newPrice <= 0) {
                return interaction.editReply({ content: '❌ أدخل رقماً صحيحاً أكبر من صفر!' });
            }

            const guildId = interaction.guild.id;
            prices.set(`${p.key}_${guildId}`, newPrice);

            // أعد عرض الأسعار المحدثة
            const embed = buildPricesEmbed(guildId);
            const select = buildSelectMenu(guildId);

            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`✅ تم تحديث سعر **${p.label}** إلى \`${newPrice}\` عملة/${p.period}`)
                        .setColor('Green')
                        .setTimestamp(),
                    embed,
                ],
                components: [new ActionRowBuilder().addComponents(select)],
            });
        }
    },
};
