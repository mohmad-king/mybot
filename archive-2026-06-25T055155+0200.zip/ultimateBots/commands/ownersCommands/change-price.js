const { ChatInputCommandInteraction, Client, SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const prices = new Database("database/settingsdata/prices.json");

// البوتات الفرعية مقسمة لمجموعتين
const GROUP1 = [
    'Broadcast', 'Invite', 'ads', 'ai', 'apply', 'auction', 'azkar',
    'blacklist', 'code', 'commerce', 'games', 'giveaway', 'marketstore',
    'mongo', 'nadeko', 'one4all', 'privateRooms', 'protect', 'quran',
    'roles', 'scammers', 'self', 'seller', 'shopRooms', 'store'
];

const GROUP2 = [
    'system', 'ticket', 'ticketbil', 'token', 'tokenbot', 'tools', 'utilities'
];

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('change-price')
        .setDescription('تغيير سعر البوت الفرعي')
        .addStringOption(option =>
            option
                .setName('group')
                .setDescription('المجموعة')
                .setRequired(true)
                .addChoices(
                    { name: 'المجموعة الأولى (Broadcast → Store)', value: 'group1' },
                    { name: 'المجموعة الثانية (System → Utilities)', value: 'group2' },
                ))
        .addStringOption(option =>
            option
                .setName('bot-type')
                .setDescription('نوع البوت')
                .setRequired(true)
                .setAutocomplete(true))
        .addIntegerOption(option =>
            option
                .setName('price')
                .setDescription('السعر بالعملات')
                .setRequired(true)),

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false });
        const group   = interaction.options.getString('group');
        const Bot_Type = interaction.options.getString('bot-type');
        const price   = interaction.options.getInteger('price');

        const allChoices = group === 'group1' ? GROUP1 : GROUP2;

        if (!allChoices.includes(Bot_Type)) {
            return interaction.editReply({ content: `**❌ نوع البوت غير صالح أو لا ينتمي للمجموعة المختارة**` });
        } else if (price < 1) {
            return interaction.editReply({ content: `**⚠️ لا يمكن تعديل سعر أي بوت ليصبح أقل من \`1 عملة\`.**` });
        } else {
            await prices.set(`${Bot_Type}_price_${interaction.guild.id}`, price);
            return interaction.editReply({ content: `**✅ تم تغيير سعر بوت \`${Bot_Type}\` إلى \`${price}\` عملة بنجاح**` });
        }
    },

    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async autocomplete(interaction) {
        const group = interaction.options.getString('group');
        const value = interaction.options.getFocused().toLowerCase();

        const allChoices = group === 'group1' ? GROUP1 : GROUP2;

        const filtered = allChoices
            .filter(choice => choice.toLowerCase().includes(value))
            .slice(0, 25);

        await interaction.respond(
            filtered.map(choice => ({ name: choice, value: choice }))
        );
    }
};
