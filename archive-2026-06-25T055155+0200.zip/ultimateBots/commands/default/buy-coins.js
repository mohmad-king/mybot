// ═══════════════════════════════════════════════════════════════
//  buy-coins.js  —  بوت البريميوم / التيميت
//
//  العميل يشتري كوينز من البوت بعد:
//   1. التحقق من أن السيرفر لديه اشتراك نشط
//   2. التحقق من أن رصيد كوينز الميكر كافٍ للطلب
//  بعد نجاح التحويل: تُضاف للعميل وتُخصم من الميكر.
//
//  المسار:
//    premiumBots/commands/default/buy-coins.js
//    ultimateBots/commands/default/buy-coins.js
// ═══════════════════════════════════════════════════════════════
const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChatInputCommandInteraction,
    Client,
    MessageFlags,
} = require('discord.js');
const { Database } = require('st.db');
const { getMakerCoins, deductMakerCoins } = require('../../../utils/makerCoinsHelper');

// ── قواعد البيانات ──
const usersdata     = new Database("database/usersdata/usersdata");
const setting       = new Database("database/settingsdata/setting");
const prices        = new Database("database/settingsdata/prices");
const buyerChecker  = new Database('Json-db/Others/buyerChecker.json');

// ── للتحقق من أن السيرفر لديه اشتراك ──
const tier2subs = new Database("database/makers/tier2/subscriptions");
const tier3subs = new Database("database/makers/tier3/subscriptions");

const { mainguild } = require('../../../config.json');

// ── مدة الانتظار (دقيقتان) ──
const WAIT_MS = 2 * 60 * 1000;

// ── جلب ID الميكر (صاحب البوت) في هذا السيرفر ──
function getGuildOwner(guildId) {
    const t3 = (tier3subs.get('tier3_subs') ?? []).find(s => s.guildid === guildId);
    if (t3) return t3.owner ?? t3.ownerid ?? null;
    const t2 = (tier2subs.get('tier2_subs') ?? []).find(s => s.guildid === guildId);
    if (t2) return t2.owner ?? t2.ownerid ?? null;
    return null;
}

module.exports = {
    ownersOnly: false, // متاح لكل أعضاء السيرفر الذين لديهم اشتراك
    data: new SlashCommandBuilder()
        .setName('buy-coins')
        .setDescription('شراء كوينز من البوت الرئيسي لتعبئة رصيدك')
        .addIntegerOption(o => o
            .setName('amount')
            .setDescription('عدد الكوينز المراد شراؤها')
            .setMinValue(1)
            .setRequired(true)
        ),

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        const guildId = interaction.guild.id;
        const userId  = interaction.user.id;
        const amount  = interaction.options.getInteger('amount');

        // ── 1. التحقق من أن السيرفر لديه اشتراك (بريميوم أو التيميت) ──
        const tier2 = (tier2subs.get('tier2_subs') ?? []).find(s => s.guildid === guildId);
        const tier3 = (tier3subs.get('tier3_subs') ?? []).find(s => s.guildid === guildId);

        if (!tier2 && !tier3 && guildId !== mainguild) {
            return interaction.reply({
                content: '**⛔ سيرفرك لا يمتلك اشتراكاً نشطاً. اشترِ اشتراك بريميوم أو التيميت أولاً.**',
                flags: MessageFlags.Ephemeral,
            });
        }

        // ── 2. التحقق من رصيد كوينز الميكر ──
        const makerId     = getGuildOwner(guildId);
        const makerCoins  = makerId ? getMakerCoins(makerId, guildId) : 0;

        if (!makerId || makerCoins < amount) {
            return interaction.reply({
                content:
                    `**⛔ لا يمكن إتمام عملية الشراء حالياً.**\n` +
                    `> 💰 **رصيد البوت المتاح:** \`${makerCoins}\` كوين\n` +
                    `> 🛒 **الكمية المطلوبة:** \`${amount}\` كوين\n\n` +
                    `رصيد البوت غير كافٍ — تواصل مع صاحب البوت لإعادة تعبئة الرصيد.`,
                flags: MessageFlags.Ephemeral,
            });
        }

        // ── 3. منع عمليات الشراء المتزامنة لنفس المستخدم ──
        const alreadyBuying = buyerChecker.get(`buyer-${userId}-${guildId}`);
        if (alreadyBuying) {
            return interaction.reply({
                content: '**⏳ لديك عملية شراء قيد التنفيذ. انتظر دقيقتين وحاول مجدداً.**',
                flags: MessageFlags.Ephemeral,
            });
        }

        // ── 4. جلب إعدادات البوت الرئيسي ──
        const recipient  = setting.get(`premium_recipient_${guildId}`);
        const logRoomId  = setting.get(`premium_log_room_${guildId}`);
        const probotId   = setting.get(`premium_probot_${guildId}`);
        const clientRole = setting.get(`premium_client_role_${guildId}`);
        const pricePerCoin = setting.get(`balance_price_global`) ?? 1000;

        if (!recipient || !logRoomId || !probotId || !clientRole) {
            return interaction.reply({
                content: '**⚠️ لم يتم تحديد إعدادات البوت. استخدم `/setup` أولاً.**',
                flags: MessageFlags.Ephemeral,
            });
        }

        // ── 5. حساب السعر ──
        // price2 = إجمالي الكريدت (بدون فائدة)
        // price3 = مع فائدة البروبوت (÷19×20 +1)
        const price2 = Math.floor(pricePerCoin * amount);
        const price3 = Math.floor(price2 * (20 / 19) + 1);

        // ── 6. إنشاء رسالة التحويل ──
        const deadline    = new Date(Date.now() + WAIT_MS);
        const deadlineTs  = Math.floor(deadline.getTime() / 1000);

        const transferCmd = `#credit ${recipient} ${price3} ${amount}coin`;

        const transferEmbed = new EmbedBuilder()
            .setTitle('💳 أكمل عملية الشراء')
            .setDescription(
                `**حوّل المبلغ التالي عبر البروبوت خلال المدة المحددة:**\n` +
                `\`\`\`js\n${transferCmd}\n\`\`\`` +
                `\n> 💰 **الكوينز:** \`${amount}\`\n` +
                `> 💵 **المبلغ:** \`${price3}\` كريدت\n` +
                `> ⏰ **ينتهي:** <t:${deadlineTs}:R>`
            )
            .setColor('Yellow')
            .setTimestamp()
            .setFooter({ text: 'سيتم إضافة الكوينز تلقائياً بعد التحويل', iconURL: interaction.guild.iconURL({ dynamic: true }) });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`copyTransfer-${userId}`)
                .setLabel('نسخ الأمر')
                .setEmoji('📋')
                .setStyle(ButtonStyle.Secondary),
        );

        const reply = await interaction.reply({
            content: `⏳ <t:${deadlineTs}:R>`,
            embeds: [transferEmbed],
            components: [row],
        });

        // ── 7. مراقبة رسالة التحويل من البروبوت ──
        await buyerChecker.set(`buyer-${userId}-${guildId}`, true);

        const collectorFilter = m =>
            m.author.id === probotId &&
            (m.content.includes(String(price2)) || m.content.includes(String(price3))) &&
            (m.content.includes(recipient) || m.content.includes(`<@${recipient}>`));

        const collector = interaction.channel.createMessageCollector({
            filter: collectorFilter,
            max: 1,
            time: WAIT_MS,
        });

        let transferred = false;

        collector.on('collect', async () => {
            transferred = true;
            await buyerChecker.delete(`buyer-${userId}-${guildId}`);

            // ── خصم الكوينز من رصيد الميكر ──
            const deductResult = deductMakerCoins(makerId, guildId, amount);
            // في هذه المرحلة نادراً ما يفشل الخصم (تحققنا مسبقاً)،
            // لكن إن حدث تعارض نلوّغه دون إيقاف العملية
            if (!deductResult.success) {
                console.error(`[buy-coins] فشل خصم كوينز الميكر: ${deductResult.message}`);
            }

            // ── إضافة الكوينز لرصيد العميل في هذا السيرفر ──
            const current = parseInt(usersdata.get(`balance_${userId}_${guildId}`)) || 0;
            const newBal  = current + amount;
            await usersdata.set(`balance_${userId}_${guildId}`, newBal);

            // ── إعطاء رول العملاء إن لم يكن موجوداً ──
            const roleObj = interaction.guild.roles.cache.get(clientRole);
            if (roleObj) {
                await interaction.member.roles.add(roleObj).catch(() => {});
            }

            // ── تعديل الرسالة الأصلية ──
            const successEmbed = new EmbedBuilder()
                .setTitle('✅ تمت عملية الشراء بنجاح!')
                .setDescription(
                    `> 💰 **الكوينز المضافة:** \`${amount}\`\n` +
                    `> 🏦 **رصيدك الحالي:** \`${newBal}\` كوين`
                )
                .setColor('Green')
                .setTimestamp();

            await reply.edit({ content: '', embeds: [successEmbed], components: [] });
            await interaction.channel.send(`> ✅ <@${userId}> تم شراء \`${amount} كوين\` بنجاح. رصيدك الحالي: \`${newBal}\` 🎉`);

            // ── لوج في روم السيرفر ──
            const logRoom = interaction.guild.channels.cache.get(logRoomId)
                ?? await interaction.guild.channels.fetch(logRoomId).catch(() => null);
            if (logRoom) {
                const makerNewBal = deductResult.success ? deductResult.newBalance : getMakerCoins(makerId, guildId);
                const logEmbed = new EmbedBuilder()
                    .setColor('Green')
                    .setDescription(
                        `**💰 تم شراء \`${amount}\` كوين بواسطة: ${interaction.user}**\n` +
                        `> رصيده الجديد: \`${newBal}\`\n` +
                        `> رصيد كوينز البوت المتبقي: \`${makerNewBal}\``
                    )
                    .setTimestamp();
                await logRoom.send({ embeds: [logEmbed] }).catch(() => {});
            }

            // ── ويب هوك لوج المشتريات في البوت الرئيسي ──
            try {
                const { WebhookClient } = require('discord.js');
                const { purchaseWebhookUrl } = require('../../../config.json');
                const wh = new WebhookClient({ url: purchaseWebhookUrl });
                const makerNewBal = deductResult.success ? deductResult.newBalance : getMakerCoins(makerId, guildId);
                const whEmbed = new EmbedBuilder()
                    .setTitle('💰 شراء كوينز — بوت ميكر')
                    .setColor('Gold')
                    .addFields(
                        { name: 'السيرفر',                value: `\`\`\`${interaction.guild.name} (${guildId})\`\`\``, inline: true },
                        { name: 'المشتري',                value: `\`\`\`${interaction.user.username} (${userId})\`\`\``, inline: true },
                        { name: 'الكوينز',                value: `\`\`\`${amount}\`\`\``,  inline: true },
                        { name: 'المبلغ المدفوع',         value: `\`\`\`${price3} كريدت\`\`\``, inline: true },
                        { name: 'الرصيد الجديد (عميل)',   value: `\`\`\`${newBal}\`\`\``, inline: true },
                        { name: 'رصيد كوينز البوت المتبقي', value: `\`\`\`${makerNewBal}\`\`\``, inline: true },
                    )
                    .setTimestamp();
                await wh.send({ embeds: [whEmbed] });
            } catch (_) {}
        });

        collector.on('end', async () => {
            if (!transferred) {
                await buyerChecker.delete(`buyer-${userId}-${guildId}`);

                const failEmbed = new EmbedBuilder()
                    .setDescription('```js\nانتهى الوقت — لم يتم الشراء\n```')
                    .setColor('Red');

                await reply.edit({ content: '', embeds: [failEmbed], components: [] });
                await interaction.channel.send(`**🙅 <@${userId}> انتهى الوقت، لا تقم بالتحويل الآن.**`);
            }
        });
    },
};
