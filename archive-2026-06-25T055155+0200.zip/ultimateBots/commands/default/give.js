// ═══════════════════════════════════════════════════════════════
//  give-coins.js  —  بوت الميكر (بريميوم / التيميت)
//
//  هذا الأمر هو أداة "بيع/تسليم" الكوينز للأعضاء.
//  الكوينز تُخصم من رصيد الميكر نفسه (مخزونه الذي اشتراه من
//  البوت الرئيسي عبر buy-coins) وتُضاف لرصيد العضو المستلم.
//
//  لا يمكن للميكر إعطاء كوينز أكثر من رصيده المتاح — إذا
//  نفذ مخزونه، يجب أن يشتري كوينز جديدة من البوت الرئيسي أولاً.
// ═══════════════════════════════════════════════════════════════
const { SlashCommandBuilder, EmbedBuilder, ChatInputCommandInteraction, Client, MessageFlags } = require("discord.js");
const { Database } = require("st.db");

const usersdata = new Database(`database/usersdata/usersdata`)

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
    .setName('give-coins')
    .setDescription('اعطاء/بيع كوينز من رصيدك لعضو (تُخصم من مخزونك)')
    .addUserOption(Option => Option
        .setName(`user`)
        .setDescription(`الشخص المراد اعطائه الرصيد`)
        .setRequired(true))
    .addIntegerOption(Option => Option
        .setName(`quantity`)
        .setDescription(`الكمية`)
        .setRequired(true)
        .setMinValue(1)),

    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false })

        const user      = interaction.options.getUser(`user`)
        const quantity  = interaction.options.getInteger(`quantity`)
        const ownerId   = interaction.user.id
        const guildId   = interaction.guild.id

        let balanceembed = new EmbedBuilder().setTimestamp()

        // ── منع إعطاء كوينز للبوتات أو لنفسه ──
        if (user.bot) {
            balanceembed.setDescription(`**❌ لا يمكنك إعطاء الكوينز لبوت**`)
            balanceembed.setColor('Red')
            return interaction.editReply({ embeds: [balanceembed] })
        }
        if (user.id === ownerId) {
            balanceembed.setDescription(`**❌ لا يمكنك إعطاء الكوينز لنفسك**`)
            balanceembed.setColor('Red')
            return interaction.editReply({ embeds: [balanceembed] })
        }

        // ── جلب رصيد الميكر (المخزون الذي اشتراه من البوت الرئيسي) ──
        const ownerBalance = parseInt(usersdata.get(`balance_${ownerId}_${guildId}`)) || 0

        // ── التحقق من أن الميكر يملك رصيداً كافياً قبل البيع/الإعطاء ──
        if (ownerBalance < quantity) {
            balanceembed.setDescription(
                `**❌ رصيدك من الكوينز غير كافٍ لإجراء هذه العملية**\n` +
                `> 🏦 **رصيدك الحالي:** \`${ownerBalance}\` كوين\n` +
                `> 💰 **المطلوب:** \`${quantity}\` كوين\n\n` +
                `استخدم \`/buy-coins\` لشراء كوينز من البوت الرئيسي أولاً.`
            )
            balanceembed.setColor('Red')
            return interaction.editReply({ embeds: [balanceembed] })
        }

        // ── تنفيذ العملية: خصم من رصيد الميكر، وإضافة لرصيد العضو ──
        const userBalance    = parseInt(usersdata.get(`balance_${user.id}_${guildId}`)) || 0
        const newOwnerBalance = ownerBalance - quantity
        const newUserBalance  = userBalance + quantity

        await usersdata.set(`balance_${ownerId}_${guildId}`, newOwnerBalance)
        await usersdata.set(`balance_${user.id}_${guildId}`, newUserBalance)

        balanceembed.setDescription(
            `**✅ تم إعطاء ${user} \`${quantity}\` كوين بنجاح**\n` +
            `> 🏦 **رصيد ${user} الحالي:** \`${newUserBalance}\` كوين\n` +
            `> 📦 **رصيدك (مخزونك) المتبقي:** \`${newOwnerBalance}\` كوين`
        )
        balanceembed.setColor('Aqua')
        return interaction.editReply({ embeds: [balanceembed] })

    }
}
