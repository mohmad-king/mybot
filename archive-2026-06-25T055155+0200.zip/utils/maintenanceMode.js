// ═══════════════════════════════════════════════════════════════
//  maintenanceMode.js — وضع الصيانة العام للبوت الرئيسي
//  يستخدمه owner-dashboard.js (للتفعيل/الإلغاء) و interactionCreate.js (للتحقق)
// ═══════════════════════════════════════════════════════════════
const { Database } = require('st.db');
const ownerDashDB = new Database('Json-db/Others/ownerDashboard');

function isMaintenanceOn() {
    return ownerDashDB.get('maintenanceMode') === true;
}

function setMaintenance(state, reason = '') {
    ownerDashDB.set('maintenanceMode', !!state);
    ownerDashDB.set('maintenanceReason', reason || '');
}

function getMaintenanceReason() {
    return ownerDashDB.get('maintenanceReason') || 'البوت تحت الصيانة حالياً، حاول مرة أخرى لاحقاً.';
}

module.exports = { isMaintenanceOn, setMaintenance, getMaintenanceReason };
