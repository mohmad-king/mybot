/**
 * نظام فحص الاشتراكات المركزي
 * بيشتغل مرة واحدة كل دقيقة ويفحص كل البوتات الفرعية
 * بدل ما كل بوت يعمل setInterval خاص بيه
 */

const { Database }  = require("st.db");
const { EmbedBuilder } = require("discord.js");
const { liveBots }  = require("./liveBots");
const tokens        = new Database("tokens/tokens");

// مفاتيح التوكن لكل البوتات الفرعية
const BOT_KEYS = [
  // ─── البوتات الحالية ───
  "ads", "ai", "apply", "auction", "azkar",
  "blacklist", "Broadcast",
  "code", "commerce",
  "games", "giveaway",
  "Invite",
  "marketstore", "mongo",
  "nadeko",
  "one4all",
  "privateRooms", "protect",
  "quran",
  "roles",
  "scammers", "self", "seller", "shopRooms", "store", "system",
  "ticket", "ticketbil", "tools",
  "utilities",
  // ─── توكنات قديمة (مدموجة) - نفحصها للبوتات القديمة ───
  "autoline", "come", "credit", "feedback", "logs",
  "offer", "orders", "suggestions", "tax",
];

async function checkAllSubscriptions(mainClient) {
  for (const key of BOT_KEYS) {
    try {
      const list = tokens.get(key);
      if (!list || !Array.isArray(list)) continue;

      const expired  = list.filter(b => !b.timeleft || b.timeleft <= 0);
      const active   = list.filter(b => b.timeleft > 0);

      for (const entry of expired) {
        const { token, clientId, owner } = entry;
        const botClient = liveBots.get(token);

        // إرسال إشعار للميكر
        try {
          const user = await mainClient.users.fetch(owner).catch(() => null);
          if (user) {
            await user.send({
              embeds: [new EmbedBuilder()
                .setDescription(`**مرحبا <@${owner}>، انتهى اشتراك بوتك <@${clientId}>.**`)
                .setColor("DarkerGrey")
                .setTimestamp()]
            }).catch(() => {});
          }
        } catch {}

        // إيقاف البوت
        if (botClient) {
          await botClient.destroy().catch(() => {});
          liveBots.delete(token);
        }

        console.log(`[checker] ${key}:${clientId} انتهى اشتراكه وتم إيقافه`);
      }

      // حذف المنتهية من قاعدة البيانات
      if (expired.length > 0) {
        await tokens.set(key, active);
      }
    } catch (err) {
      console.error(`[checker] خطأ في فحص ${key}:`, err.message);
    }
  }
}

/**
 * تفعيل النظام المركزي (يُستدعى مرة واحدة من index.js)
 * @param {Client} mainClient - البوت الرئيسي عشان يجيب users
 */
function startSubscriptionChecker(mainClient) {
  console.log("[checker] ✅ نظام فحص الاشتراكات المركزي شغال");
  setInterval(() => checkAllSubscriptions(mainClient), 60_000);
}

module.exports = { startSubscriptionChecker };
