/**
 * نظام فحص الجيف اويات الخاصة ببوت الإعلانات
 * يشتغل مرة واحدة كل دقيقة (نفس نمط subscriptionChecker.js):
 *  - يسحب فايز تلقائياً عند انتهاء وقت الجيف اوي
 *  - يحذف الروم الخاص (نوع 3) تلقائياً بعد 5 ساعات من انتهاء الجيف اوي
 */
const { Database } = require("st.db");
const { EmbedBuilder } = require("discord.js");
const { liveBots } = require("./liveBots");
const tokens = new Database("tokens/tokens");
const giveawayDB = new Database("Json-db/Bots/adsGiveawayDB.json");

const ROOM_DELETE_AFTER_MS = 1000 * 60 * 60 * 5; // 5 ساعات بعد انتهاء الجيف اوي

function pickWinners(entries, count) {
  const pool = [...entries];
  const winners = [];
  while (pool.length > 0 && winners.length < count) {
    const idx = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(idx, 1)[0]);
  }
  return winners;
}

async function endGiveaway(client, giveaway, guildId) {
  giveaway.ended = true;
  giveaway.roomDeleteAt = giveaway.roomId ? Date.now() + ROOM_DELETE_AFTER_MS : null;

  try {
    const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
    if (!channel) return;

    const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
    const winners = pickWinners(giveaway.entries, giveaway.winners);

    const resultEmbed = new EmbedBuilder()
      .setTitle(`🎉 ${giveaway.prize}`)
      .setColor("#22c55e")
      .setDescription(
        winners.length > 0
          ? `انتهى الجيف اوي!\nالفائزون: ${winners.map(w => `<@${w}>`).join(", ")}`
          : "انتهى الجيف اوي ولم يشارك أحد."
      )
      .setTimestamp();

    if (message) await message.edit({ embeds: [resultEmbed], components: [] }).catch(() => {});

    await channel.send({
      content: winners.length > 0 ? winners.map(w => `<@${w}>`).join(" ") : null,
      embeds: [
        new EmbedBuilder()
          .setColor("#22c55e")
          .setDescription(
            winners.length > 0
              ? `🎉 تهانينا! لقد فزت بـ **${giveaway.prize}**`
              : `😔 لم يشترك أحد في جيف اوي **${giveaway.prize}**`
          )
      ],
    }).catch(() => {});
  } catch (err) {
    console.error("[adsGiveawayChecker] خطأ في إنهاء جيف اوي:", err.message);
  }
}

async function deleteRoom(client, giveaway) {
  try {
    const channel = await client.channels.fetch(giveaway.roomId).catch(() => null);
    if (channel) await channel.delete().catch(() => {});
  } catch (err) {
    console.error("[adsGiveawayChecker] خطأ في حذف الروم:", err.message);
  }
}

async function checkAllAdsGiveaways() {
  const adsTokens = tokens.get("ads") || [];

  for (const entry of adsTokens) {
    const client = liveBots.get(entry.token);
    if (!client) continue;

    for (const guild of client.guilds.cache.values()) {
      const gid = guild.id;
      const giveaways = giveawayDB.get(`giveaways_${gid}`);
      if (!giveaways || giveaways.length === 0) continue;

      let changed = false;

      for (const giveaway of giveaways) {
        // 1) إنهاء الجيف اويات اللي خلص وقتها
        if (!giveaway.ended && Date.now() >= giveaway.endsAt) {
          await endGiveaway(client, giveaway, gid);
          changed = true;
        }

        // 2) حذف الروم الخاص بعد 5 ساعات من انتهاء الجيف اوي
        if (giveaway.ended && giveaway.roomId && giveaway.roomDeleteAt && Date.now() >= giveaway.roomDeleteAt) {
          await deleteRoom(client, giveaway);
          giveaway.roomId = null; // يمنع إعادة محاولة الحذف
          changed = true;
        }
      }

      if (changed) await giveawayDB.set(`giveaways_${gid}`, giveaways);
    }
  }
}

function startAdsGiveawayChecker() {
  console.log("[adsGiveawayChecker] ✅ نظام فحص جيف اويات الإعلانات شغال");
  setInterval(() => {
    checkAllAdsGiveaways().catch(err => console.error("[adsGiveawayChecker] خطأ:", err.message));
  }, 60_000);
}

module.exports = { startAdsGiveawayChecker };
