// ═══════════════════════════════════════════════════════════════
//  makerCreditsHelper.js
// ═══════════════════════════════════════════════════════════════
const { Database } = require('st.db');
const path = require('path');
const fs = require('fs');

// st.db بتحسب المسار من process.cwd() (مجلد تشغيل البوت)
// فنحتاج مسار نسبي من جذر المشروع مش مطلق

const dbDir1 = path.join(process.cwd(), 'database/makerCredits');
const dbDir2 = path.join(process.cwd(), 'database/makers/tier3');

if (!fs.existsSync(dbDir1)) fs.mkdirSync(dbDir1, { recursive: true });
if (!fs.existsSync(dbDir2)) fs.mkdirSync(dbDir2, { recursive: true });

const makerCreditsDB = new Database('./database/makerCredits/makerCredits');
const tier3subs      = new Database('./database/makers/tier3/subscriptions');

const SECS_PER_DAY = 86400;

function getMakerCredits(userId) {
    return makerCreditsDB.get(`credits_${userId}`) ?? { prime: 0, premium: 0, ultimate: 0 };
}

function setMakerCredits(userId, credits) {
    makerCreditsDB.set(`credits_${userId}`, credits);
}

function getUltimateSub(guildId) {
    const subs = tier3subs.get('tier3_subs') ?? [];
    return subs.find(s => s.guildid === guildId) ?? null;
}

function canMakerSell(guildId, type) {
    const sub = getUltimateSub(guildId);
    if (!sub) return false;
    if (type === 'ultimate') return sub.ultimatePlus === true;
    return true;
}

function deductMakerCredits(makerId, type, days) {
    const credits = getMakerCredits(makerId);
    if ((credits[type] ?? 0) < days) {
        return {
            success: false,
            message: `❌ رصيدك من اشتراكات **${type}** غير كافٍ!\n> رصيدك الحالي: \`${credits[type] ?? 0}\` يوم\n> المطلوب: \`${days}\` يوم\n\nاستخدم \`/maker-sub buy-credits\` لشراء المزيد.`
        };
    }
    credits[type] -= days;
    setMakerCredits(makerId, credits);
    return { success: true };
}

function refundMakerCredits(makerId, type, days) {
    const credits = getMakerCredits(makerId);
    credits[type] = (credits[type] ?? 0) + days;
    setMakerCredits(makerId, credits);
}

module.exports = {
    getMakerCredits,
    setMakerCredits,
    getUltimateSub,
    canMakerSell,
    deductMakerCredits,
    refundMakerCredits,
    SECS_PER_DAY,
};
