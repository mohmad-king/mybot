// ═══════════════════════════════════════════════════════════════
//  makerCoinsHelper.js  —  مساعد كوينز الميكر
//
//  يوفر دوال بسيطة لقراءة وتعديل رصيد كوينز الميكر.
//  الرصيد مخزّن في usersdata بمفتاح: balance_${makerId}_${guildId}
//
//  الدوال المتاحة:
//    getMakerCoins(makerId, guildId) → number
//    setMakerCoins(makerId, guildId, amount) → void
//    addMakerCoins(makerId, guildId, amount) → number  (الرصيد الجديد)
//    deductMakerCoins(makerId, guildId, amount) → { success, newBalance, message? }
//    findGuildSubscription(guildId) → { tier, tierLabel, record } | null
//    validateMakerOwnership(makerId, guildId) → { valid, tier?, tierLabel?, actualOwnerId?, message? }
// ═══════════════════════════════════════════════════════════════
const { Database } = require('st.db');

const usersdata = new Database("database/usersdata/usersdata");
const tier2subs = new Database("database/makers/tier2/subscriptions");
const tier3subs = new Database("database/makers/tier3/subscriptions");

// ── يدعم اختلاف اسم حقل المالك بين التيرز (owner vs ownerid) ──
function recordOwnerId(record) {
    return record?.owner ?? record?.ownerid ?? null;
}

/**
 * البحث عن اشتراك سيرفر معيّن في كل التيرز، بصرف النظر عن اسم حقل المالك
 * @param {string} guildId
 * @returns {{ tier: 1|2|3, tierLabel: string, record: object } | null}
 */
function findGuildSubscription(guildId) {

    const t2 = (tier2subs.get('tier2_subs') ?? []).find(s => s.guildid === guildId);
    if (t2) return { tier: 2, tierLabel: '💎 البريميوم', record: t2 };

    const t3 = (tier3subs.get('tier3_subs') ?? []).find(s => s.guildid === guildId);
    if (t3) return { tier: 3, tierLabel: '🔥 التيميت', record: t3 };

    return null;
}

/**
 * تتحقق من أن maker_id المُدخل هو فعلاً مالك (owner) السيرفر guild_id
 * المسجَّل في جدول الاشتراكات. تمنع كتابة/قراءة الرصيد على مفتاح خاطئ
 * بسبب إدخال آيدي غير مرتبط بهذا السيرفر (مثل آيدي توكن البوت بالخطأ).
 *
 * @param {string} makerId
 * @param {string} guildId
 * @returns {{ valid: boolean, tier?: number, tierLabel?: string, actualOwnerId?: string|null, message?: string }}
 */
function validateMakerOwnership(makerId, guildId) {
    const sub = findGuildSubscription(guildId);

    if (!sub) {
        return {
            valid: false,
            actualOwnerId: null,
            message:
                `تأكد من \`guild_id\` قبل المحاولة مجدداً.`,
        };
    }

    const actualOwnerId = recordOwnerId(sub.record);

    if (actualOwnerId !== makerId) {
        return {
            valid: false,
            tier: sub.tier,
            tierLabel: sub.tierLabel,
            actualOwnerId,
            message:
                `**⛔ الـ \`maker_id\` المُدخل (\`${makerId}\`) لا يطابق صاحب هذا السيرفر المسجَّل في الاشتراك.**\n` +
                `> 🏠 **السيرفر:** \`${guildId}\` (${sub.tierLabel})\n` +
                `> 👤 **الآيدي الصحيح المسجَّل لصاحب البوت:** \`${actualOwnerId ?? 'غير محدد'}\`\n\n` +
                `استخدم هذا الآيدي بدلاً من الذي أدخلته لتفادي إضافة/خصم الكوينز على مفتاح خاطئ.`,
        };
    }

    return { valid: true, tier: sub.tier, tierLabel: sub.tierLabel, actualOwnerId };
}

/**
 * جلب رصيد كوينز الميكر في سيرفر بوته
 * @param {string} makerId  — Discord ID للميكر
 * @param {string} guildId  — ID سيرفر بوت الميكر
 * @returns {number}
 */
function getMakerCoins(makerId, guildId) {
    return parseInt(usersdata.get(`balance_${makerId}_${guildId}`)) || 0;
}

/**
 * تعيين رصيد كوينز الميكر مباشرةً
 * @param {string} makerId
 * @param {string} guildId
 * @param {number} amount
 */
function setMakerCoins(makerId, guildId, amount) {
    usersdata.set(`balance_${makerId}_${guildId}`, Math.max(0, amount));
}

/**
 * إضافة كوينز لرصيد الميكر
 * @param {string} makerId
 * @param {string} guildId
 * @param {number} amount
 * @returns {number} الرصيد الجديد
 */
function addMakerCoins(makerId, guildId, amount) {
    const current = getMakerCoins(makerId, guildId);
    const newBal  = current + amount;
    usersdata.set(`balance_${makerId}_${guildId}`, newBal);
    return newBal;
}

/**
 * خصم كوينز من رصيد الميكر مع التحقق من الكفاية
 * @param {string} makerId
 * @param {string} guildId
 * @param {number} amount
 * @returns {{ success: boolean, newBalance?: number, message?: string }}
 */
function deductMakerCoins(makerId, guildId, amount) {
    const current = getMakerCoins(makerId, guildId);

    if (current < amount) {
        return {
            success: false,
            message:
                `❌ **رصيد كوينز البوت غير كافٍ لإتمام العملية!**\n` +
                `> 💰 **رصيدك الحالي:** \`${current}\` كوين\n` +
                `> 🛒 **المطلوب:** \`${amount}\` كوين\n\n` +
                `استخدم \`/maker-coins buy\` لشراء المزيد من الكوينز.`,
        };
    }

    const newBalance = current - amount;
    usersdata.set(`balance_${makerId}_${guildId}`, newBalance);
    return { success: true, newBalance };
}

module.exports = {
    getMakerCoins,
    setMakerCoins,
    addMakerCoins,
    deductMakerCoins,
    findGuildSubscription,
    validateMakerOwnership,
};
