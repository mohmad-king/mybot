/**
 * isOwner - يتحقق إذا المستخدم أونر (من config) أو صاحب السيرفر
 * @param {string} userId 
 * @param {import('discord.js').Guild} guild 
 * @returns {boolean}
 */
const { owner } = require('../config.json');

function isOwner(userId, guild) {
    if (owner.includes(userId)) return true;
    if (guild && guild.ownerId === userId) return true;
    return false;
}

module.exports = { isOwner };
