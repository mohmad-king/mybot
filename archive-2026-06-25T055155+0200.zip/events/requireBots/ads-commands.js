const fs = require('fs');
const ascii = require('ascii-table');
let table = new ascii(`commands`);
table.setHeading('Command', 'Commands Status💹');
const path = require('path');

module.exports = (clientAds) => {
    const commandsDir = path.join(__dirname, '../../Bots/ads/slashcommand_ads');
    if (!fs.existsSync(commandsDir)) return;
    fs.readdirSync(commandsDir).forEach((folder) => {
        const folderPath = path.join(commandsDir, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            let command = require(filePath);
            if (command && command.data && command.data.name) {
                clientAds.commands.set(command.data.name, command);
            }
        }
    });
};
