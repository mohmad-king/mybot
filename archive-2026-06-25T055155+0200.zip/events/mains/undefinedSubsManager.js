const { Client, Collection,ActivityType, discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message } = require("discord.js");
const { Database } = require("st.db")
const tier2subscriptions = new Database("database/makers/tier2/subscriptions")
const tier3subscriptions = new Database("database/makers/tier3/subscriptions")
const makers = new Database("database/makers/tier2/subscriptions")
const { token , prefix , owner , mainguild , database} = require(`../../config.json`)

module.exports = {
	name: Events.ClientReady,
	once: true,
	async execute(client) {
                if(!tier2subscriptions.has(`tier2_subs`)) {
                    await tier2subscriptions.set(`tier2_subs` , [])
                }             
                if(!tier3subscriptions.has(`tier3_subs`)) {
                  await tier3subscriptions.set(`tier3_subs` , []) 
                }             
				let info = makers.get(`tier2_subs`)
				if(!info) {
                    await makers.set(`tier2_subs` , [])
				}
	},
};
