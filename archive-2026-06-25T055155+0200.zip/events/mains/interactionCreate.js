const { Events, Interaction, EmbedBuilder ,InteractionType } = require('discord.js');
const { mainguild } = require('../../config.json');

module.exports = {
  name: Events.InteractionCreate,
    /**
    * @param {Interaction} interaction
  */
  async execute(interaction){
    if (interaction.isChatInputCommand()) {
	    if(interaction.user.bot) return;
	     let client = interaction.client;
		const command = interaction.client.slashcommands.get(interaction.commandName);
	    
		if (!command) {
			console.error(`No command matching ${interaction.commandName} was found.`);
			return;
		}
		if (command.mainGuildOnly === true) {
			if (mainguild != interaction.guild.id) {
			  return interaction.reply({content: `❗ ***هذا الامر خاص بالمطورين***`, flags: 64});
			}
		}


		if (command.ownersOnly === true) {
			const { isOwner } = require('../../utils/isOwner');
			if (!isOwner(interaction.user.id, interaction.guild)) {
				return interaction.reply({ content: '❌ لا تستطيع استخدام هذا الأمر', ephemeral: true });
			}
		}
		try {
			await command.execute(interaction, interaction.client);
		} catch (err){
			console.error('[interactionCreate] Error in command', interaction.commandName, err)
			try {
				const errMsg = { content: `❗ ***حدث خطأ غير متوقع أثناء تنفيذ الأمر***`, ephemeral: true };
				if (interaction.deferred) {
					await interaction.editReply(errMsg);
				} else if (interaction.replied) {
					await interaction.followUp(errMsg);
				} else {
					await interaction.reply(errMsg);
				}
			} catch (replyErr) {
				console.error('[interactionCreate] Failed to send error reply:', replyErr.message)
			}
		}
    }

	if(interaction.isAutocomplete()){
		const command = interaction.client.slashcommands.get(interaction.commandName);
	    
		if (!command) {
			console.error(`No command matching ${interaction.commandName} was found.`);
			return;
		}

		try {
			await command.autocomplete(interaction)
		} catch (error) {
			console.log(error)
		}
	}

  }
}