const {
    Client, Collection, ActivityType, discord, GatewayIntentBits, Partials,
    EmbedBuilder, ApplicationCommandOptionType, Events, ActionRowBuilder,
    ButtonBuilder, MessageAttachment, ButtonStyle, Message
} = require("discord.js");
const { Database } = require("st.db");
const tokens   = new Database("tokens/tokens");
const statuses = new Database("database/settingsdata/statuses");
const prices   = new Database("database/settingsdata/prices.json");
const setting  = new Database("database/settingsdata/setting");
const botStatusDB = new Database("Json-db/Others/botStatus");

// ─── تعريف البوتات ─────────────────────────────────────────────────────────
const theBots = [
    { name: `التقديم`,              defaultPrice: 40,  tradeName: `apply`        },
    { name: `الاذكار`,              defaultPrice: 40,  tradeName: `azkar`        },
    { name: `القرأن`,               defaultPrice: 40,  tradeName: `quran`        },
    { name: `الخط التلقائي`,        defaultPrice: 40,  tradeName: `autoline`     },
    { name: `البلاك ليست`,          defaultPrice: 40,  tradeName: `blacklist`    },
    { name: `الطلبات`,              defaultPrice: 40,  tradeName: `orders`       },
    { name: `رومات الشوب`,          defaultPrice: 40,  tradeName: `shopRooms`    },
    { name: `التحكم في البرودكاست`, defaultPrice: 100, tradeName: `Bc`           },
    { name: `البرودكاست العادي`,    defaultPrice: 40,  tradeName: `Broadcast2`   },
    { name: `الرومات الخاصة`,       defaultPrice: 70,  tradeName: `privateRooms` },
    { name: `الكريدت الوهمي`,       defaultPrice: 40,  tradeName: `credit`       },
    { name: `الاراء`,               defaultPrice: 40,  tradeName: `feedback`     },
    { name: `الجيف اواي`,           defaultPrice: 40,  tradeName: `giveaway`     },
    { name: `اللوج`,                defaultPrice: 40,  tradeName: `logs`         },
    { name: `الناديكو`,             defaultPrice: 40,  tradeName: `nadeko`       },
    { name: `البروبوت بريميوم الوهمي`, defaultPrice: 40, tradeName: `probot`    },
    { name: `الحماية`,              defaultPrice: 40,  tradeName: `protect`      },
    { name: `شراء الرتب`,           defaultPrice: 70,  tradeName: `roles`        },
    { name: `النصابين`,             defaultPrice: 40,  tradeName: `scam`         },
    { name: `الاقتراحات`,           defaultPrice: 40,  tradeName: `suggestions`  },
    { name: `السيستم`,              defaultPrice: 100, tradeName: `system`       },
    { name: `الضريبة`,              defaultPrice: 40,  tradeName: `tax`          },
    { name: `التكت`,                defaultPrice: 160, tradeName: `ticket`       },
    { name: `الشوب`,                defaultPrice: 70,  tradeName: `shop`         },
    { name: `واحد للكل`,            defaultPrice: 200, tradeName: `one4all`      },
    { name: `العروض`,               defaultPrice: 60,  tradeName: `offer`        },
    { name: `الالعاب`,              defaultPrice: 60,  tradeName: `games`        },
    { name: `المتجر`,               defaultPrice: 60,  tradeName: `store`        },
    { name: `أدوات مساعدة`,         defaultPrice: 60,  tradeName: `utilities`    },
    { name: `أدوات`,               defaultPrice: 60,  tradeName: `tools`        },
    { name: `التجارة`,              defaultPrice: 60,  tradeName: `commerce`     },
    { name: `المتجر الموحد`,        defaultPrice: 100, tradeName: `marketstore`  },
    { name: `الكودات`,              defaultPrice: 40,  tradeName: `code`         },
    { name: `المنغو`,               defaultPrice: 60,  tradeName: `mongo`        },
    { name: `التوكن`,               defaultPrice: 60,  tradeName: `token`        },
    { name: `بوت التوكن`,           defaultPrice: 60,  tradeName: `tokenbot`     },
    { name: `البائع`,               defaultPrice: 60,  tradeName: `seller`       },
    { name: `الذكاء الاصطناعي`,     defaultPrice: 60,  tradeName: `ai`           },
    { name: `المزاد`,               defaultPrice: 60,  tradeName: `auction`      },
    { name: `السيلف`,               defaultPrice: 40,  tradeName: `self`         },
    { name: `الإعلانات`,            defaultPrice: 80,  tradeName: `ads`          },
    { name: `الدعوات`,              defaultPrice: 40,  tradeName: `Invite`       },
    { name: `التكت (بيل)`,          defaultPrice: 120, tradeName: `ticketbil`    },
];

// ─── حساب وقت الرفع ─────────────────────────────────────────────────────────
function getUptimeString() {
    const total   = process.uptime();
    const days    = Math.floor(total / 86400);
    const hours   = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = Math.floor(total % 60);
    const parts   = [];
    if (days)    parts.push(`\`${days}\` يوم`);
    if (hours)   parts.push(`\`${hours}\` ساعة`);
    if (minutes) parts.push(`\`${minutes}\` دقيقة`);
    parts.push(`\`${seconds}\` ثانية`);
    return parts.join(" و ");
}

// ─── بناء الإمبدز الرئيسي ────────────────────────────────────────────────────
function buildStatusEmbed(guild) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString("ar-SA", {
        hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true
    });
    const dateStr = now.toLocaleDateString("ar-SA", {
        weekday: "long", year: "numeric", month: "long", day: "numeric"
    });

    // حساب إجماليات
    let totalOnline  = 0;
    let totalOffline = 0;
    let totalBots    = 0;

    const botLines = theBots.map(bot => {
        const isOn      = botStatusDB.get(bot.tradeName) !== "off";
        const tokenData = tokens.get(bot.tradeName) ?? [];
        const count     = Array.isArray(tokenData) ? tokenData.length : 0;
        const price     = prices.get(bot.tradeName + `_price_` + guild.id) ?? bot.defaultPrice;
        const status    = isOn ? "🟢" : "🔴";

        if (isOn) totalOnline++; else totalOffline++;
        totalBots += count;

        return { bot, isOn, count, price, status };
    });

    // ─── Embed 1: ملخص إحصائي ───────────────────────────────────────────────
    const embedSummary = new EmbedBuilder()
        .setTitle(`🤖 الحالة العامة للبوتات`)
        .setDescription(
            `> 📅 **${dateStr}**\n` +
            `> 🕐 **آخر تحديث:** ${timeStr}\n\n` +
            `📊 **ملخص سريع**\n` +
            `\`\`\`\n` +
            `✅ شغّالة   : ${totalOnline} بوت\n` +
            `❌ متوقفة  : ${totalOffline} بوت\n` +
            `🤖 إجمالي  : ${totalBots} توكن متاح\n` +
            `\`\`\``
        )
        .setColor(totalOffline === 0 ? 0x2ecc71 : totalOffline <= 3 ? 0xf39c12 : 0xe74c3c)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .setFooter({ text: `${guild.name} • يتجدد كل دقيقة`, iconURL: guild.iconURL({ dynamic: true }) });

    // ─── Embed 2: تفاصيل البوتات (أعمدة 2) ─────────────────────────────────
    const embedDetails = new EmbedBuilder()
        .setTitle(`📋 تفاصيل جميع البوتات`)
        .setColor(0x5865F2);

    // نقسّم البوتات على حقلين جنباً إلى جنب
    const half = Math.ceil(botLines.length / 2);
    const col1 = botLines.slice(0, half);
    const col2 = botLines.slice(half);

    const formatCol = (arr) =>
        arr.map(({ bot, status, count, price }) =>
            `${status} **${bot.name}**\n` +
            `┣ 💰 \`${price}\` عملة\n` +
            `┗ 🤖 \`${count}\` بوت`
        ).join("\n\n");

    embedDetails.addFields(
        { name: "┄┄┄┄┄┄┄┄┄┄┄┄", value: formatCol(col1), inline: true },
        { name: "┄┄┄┄┄┄┄┄┄┄┄┄", value: formatCol(col2), inline: true }
    );

    // ─── Embed 3: وقت التشغيل + إشعارات ────────────────────────────────────
    const offlineBots = botLines.filter(b => !b.isOn).map(b => `🔴 **${b.bot.name}**`);

    const embedUptime = new EmbedBuilder()
        .setColor(0x2c2f33)
        .addFields({
            name: `⏱️ مدة التشغيل بدون انقطاع`,
            value: getUptimeString(),
            inline: false
        });

    if (offlineBots.length > 0) {
        embedUptime.addFields({
            name: `⚠️ البوتات المتوقفة حالياً`,
            value: offlineBots.join("  •  "),
            inline: false
        });
    } else {
        embedUptime.addFields({
            name: `✅ حالة النظام`,
            value: `جميع البوتات تعمل بشكل طبيعي`,
            inline: false
        });
    }

    embedUptime
        .setFooter({ text: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
        .setTimestamp();

    return [embedSummary, embedDetails, embedUptime];
}

// ─── التصدير الرئيسي ─────────────────────────────────────────────────────────
module.exports = {
    name: Events.ClientReady,
    once: true,
    execute(client) {
        setInterval(() => {
            client.guilds.cache.forEach(async (guild) => {
                try {
                    const messageInfo = setting.get(`statusmessageinfo_${guild.id}`);
                    if (!messageInfo) return;

                    const { messageid, channelid } = messageInfo;
                    const theChan = guild.channels.cache.find(ch => ch.id == channelid);
                    if (!theChan || !messageid) return;

                    await theChan.messages.fetch(messageid).catch(() => {});
                    const theMsg = theChan.messages.cache.find(ms => ms.id == messageid);
                    if (!theMsg) return;

                    const embeds = buildStatusEmbed(guild);
                    await theMsg.edit({ embeds });
                } catch (err) {
                    // تجاهل الأخطاء بصمت
                }
            });
        }, 60 * 1000);
    },
};
