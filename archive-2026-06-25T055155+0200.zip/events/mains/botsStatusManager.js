const { Database } = require('st.db')
const botStatusDB = new Database("Json-db/Others/botStatus")
const tokens = new Database("tokens/tokens")
const { readdirSync } = require("fs")
const fs = require("fs")
const path = require('path');

// ------------- حالة البوتات العادية -------------------//
// ------------------------------------------------//
var AsciiTable = require('ascii-table')
const tablee = new AsciiTable('Normal Bots')
tablee.setHeading('' , 'Type' , 'Length' ,'Status')

checkStatus(`ticket`       , '../../Bots/ticket/ticket-Bots'                 , 10_000)
checkStatus(`ticketbil`    , '../../Bots/ticketbil/ticketbil-Bots'           , 10_000)
checkStatus(`Bc`           , '../../Bots/Broadcast/Broadcast-Bots'           , 10_000)
checkStatus(`games`        , '../../Bots/games/games-Bots'                   , 10_000)
checkStatus(`apply`        , '../../Bots/apply/apply-Bots'                   , 10_000)
checkStatus(`azkar`        , '../../Bots/azkar/azkar-Bots'                   , 10_000)
checkStatus(`blacklist`    , '../../Bots/blacklist/blacklist-Bots'           , 10_000)
checkStatus(`Invite`       , '../../Bots/Invite/Invite-Bots'                 , 10_000)
checkStatus(`giveaway`     , '../../Bots/giveaway/giveaway-Bots'             , 10_000)
checkStatus(`privateRooms` , '../../Bots/privateRooms/privateRooms-Bots'     , 10_000)
checkStatus(`protect`      , '../../Bots/protect/protect-Bots'               , 10_000)
checkStatus(`quran`        , '../../Bots/quran/quran-Bots'                   , 10_000)
checkStatus(`roles`        , '../../Bots/roles/roles-Bots'                   , 10_000)
checkStatus(`scam`         , '../../Bots/scammers/Scammers-Bots'             , 10_000)  // ✅ تم تصحيح الحرف الكبير
checkStatus(`shopRooms`    , '../../Bots/shopRooms/shopRooms-Bots'           , 10_000)
checkStatus(`system`       , '../../Bots/system/system-Bots'                 , 10_000)
checkStatus(`marketstore`  , '../../Bots/marketstore/marketstore-Bots'       , 10_000)
checkStatus(`ai`           , '../../Bots/ai/ai-Bots'                         , 10_000)
checkStatus(`auction`      , '../../Bots/auction/auction-Bots'               , 10_000)
checkStatus(`code`         , '../../Bots/code/code-Bots'                     , 10_000)
checkStatus(`commerce`     , '../../Bots/commerce/commerce-Bots'             , 10_000)
checkStatus(`mongo`        , '../../Bots/mongo/mongo-Bots'                   , 10_000)
checkStatus(`nadeko`       , '../../Bots/nadeko/nadeko-Bots'                 , 10_000)
checkStatus(`one4all`      , '../../Bots/one4all/One4all-Bots'               , 10_000)
checkStatus(`self`         , '../../Bots/self/self-Bots'                     , 10_000)
checkStatus(`seller`       , '../../Bots/seller/seller-Bots'                 , 10_000)
checkStatus(`store`        , '../../Bots/store/store-Bots'                   , 10_000)
checkStatus(`token`        , '../../Bots/token/token-Bots'                   , 10_000)
checkStatus(`tokenbot`     , '../../Bots/tokenbot/tokenbot-Bots'             , 10_000)
checkStatus(`tools`        , '../../Bots/tools/tools-Bots'                   , 10_000)
checkStatus(`utilities`    , '../../Bots/utilities/utilities-Bots'           , 10_000)
checkStatus(`ads`          , '../../Bots/ads/ads-Bots'                       , 10_000)

function checkStatus(type , filePath , interval) {
	// ملاحظة: تحميل البوتات يتم عبر subBotLoader.js عند الاستعداد
	// هذه الدالة تحتفظ بالاسم للتوافق مع الكود القديم فقط
	// require() محذوف لمنع التحميل المزدوج
}

const theBots = [
    {
        name:`التقديم` , defaultPrice:40,tradeName:`apply`
    },
    {
        name:`الاذكار`,defaultPrice:40,tradeName:`azkar`
    },
    {
        name:`القرأن`,defaultPrice:40,tradeName:`quran`
    },
    {
        name:`البلاك ليست` , defaultPrice:40,tradeName:`blacklist`
    },
    {
        name:`رومات الشوب`,defaultPrice:40,tradeName:`shopRooms`
    },
    {
        name:`التحكم في البرودكاست` , defaultPrice:100,tradeName:`Bc`
    },
    {
      name:`الرومات الخاصة` , defaultPrice:70,tradeName:`privateRooms`  
    },
    {
        name:`الدعوات` , defaultPrice:40,tradeName:`Invite`
    },
    {
        name:`الجيف اواي` , defaultPrice:40,tradeName:`giveaway`
    },
    {
        name:`الحماية` , defaultPrice:40 , tradeName:`protect`
    },
    {
        name:`شراء الرتب` , defaultPrice:70 , tradeName:`roles`
    },
    {
        name:`النصابين` , defaultPrice:40,tradeName:`scam`
    },
    {
        name:`السيستم` , defaultPrice:100 , tradeName:`system`
    },
      {

                            name:`الألعاب`,defaultPrice:40,tradeName:`games`

                        },
    {
        name:`التكت` , defaultPrice:160,tradeName:`ticket`
    },
    {
        name:`التكت (بيل)` , defaultPrice:120,tradeName:`ticketbil`
    },
    {
        name:`المتجر الموحد` , defaultPrice:100,tradeName:`marketstore`
    },
    {
        name : `واحد للكل` , defaultPrice:200,tradeName:`one4all`
    }
]

async function loadBotStatus() {
    for (let index = 0; index < theBots.length; index++) {
        const bot = theBots[index];
        try {
            let theBotTokens = await tokens.get(bot.tradeName) || [];
            tablee.addRow(index + 1, bot.tradeName, `${theBotTokens.length ?? 0}`, `${botStatusDB.get(bot.tradeName) === "off" ? "🔴 Not Working" : "🟢 Working"}`);
        } catch (err) {
            tablee.addRow(index + 1, bot.tradeName, `0`, `⚠️ Error`);
        }
    }
    console.log(tablee.toString());
}
loadBotStatus();
// ------------------------------------------------//

//--------------- حالة بوتات الميكر --------------//
// ------------------------------------------------//
const ultimateBotsPath = path.resolve(__dirname, '../../ultimateBots/');

// Premium bots loader
function loadPremiumBots() {
    try {
        if (botStatusDB.get(`premuimMaker`) !== "off") {
            const premiumBase = path.resolve(__dirname, '../../premiumBots/');
            if (!fs.existsSync(premiumBase)) return;
            
            for (let folder of readdirSync(premiumBase).filter(folder => !folder.includes('.'))) {
                const folderPath = path.join(premiumBase, folder);
                for (let file of readdirSync(folderPath).filter(f => f.endsWith('.js'))) {
                    try {
                        require(path.join(folderPath, file));
                    } catch (err) {
                        // silent fail for individual files
                    }
                }
            }
        }
    } catch (err) {
        // silent fail if premiumBots folder doesn't exist
    }
}

// Ultimate bots loader
function loadUltimateBots() {
    try {
        if (!fs.existsSync(ultimateBotsPath)) return;
        
        for (let folder of readdirSync(ultimateBotsPath).filter(folder => !folder.includes('.'))) {
            const folderPath = path.join(ultimateBotsPath, folder);
            for (let file of readdirSync(folderPath).filter(f => f.endsWith('.js'))) {
                try {
                    require(path.join(folderPath, file));
                } catch (err) {
                    // silent fail for individual files
                }
            }
        }
    } catch (err) {
        // silent fail if ultimateBots folder doesn't exist
    }
}

setInterval(loadPremiumBots, 5_000);
setInterval(loadUltimateBots, 5_000);
// ------------------------------------------------//

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        // Bot status manager runs on startup via loadBotStatus() above
    }
};
